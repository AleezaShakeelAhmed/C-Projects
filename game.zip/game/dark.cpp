#include <iostream>
#include <conio.h>
#include <windows.h>
#include <time.h>
#include <fstream>
#include <string>
using namespace std;
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE color = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;
void gotoxy(int y, int x)
{
    COORD coordinates;
    coordinates.X = x;
    coordinates.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
}

// function prototypes
void loadmaze(char maze[][92]);
void printmaze(char maze[][92]);
int random(int &man1x, int &w, int &x, int &y, int &v, int &ran1x, int &ran2x, int &ran3x, int &ran4x, int &ran5x, int &ran6x, int &ran7x, int &ran8x, int &ran9x, int &ran10x, int &ran11x, int &ran12x, int &ran13x, int &ran14x, int &ran15x, int &ran1y, int &ran2y, int &ran3y, int &ran4y, int &ran5y, int &ran6y, int &ran7y, int &ran8y, int &ran9y, int &ran10y, int &ran11y, int &ran12y, int &ran13y, int &ran14y, int &ran15y, int &f1y, int &f2y, int &f3y, int &f4y, int &f5y, int &f6y, int &f7y, int &f8y, int &f9y, int &f10y, int &f11y, int &f12y, int &f13y, int &f14y, int &f15y, int &endx, int &check);
void movecar(int &carY, int &carX, int &car1X, int &car1y);
void jump(int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y);
void right(int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y);
void left(int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y);
bool collide(int &man3y, int &man4y, int &carY, int &car1Y);
void instructions();
void exit();
void title();
void food(int &score, int &man1x, int &man1y, char maze[][92]);
void halfman(int &man3x, int &man3y, int &man4x, int &man4y);
void coordinates(int &carX, int &carY, int &car1X, int &car1Y, int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y, int &result);
void ResetCoR(int &w, int &x, int &y, int &v);
bool collideobjects(int &man1x, int &man1y, int &f1y, int &f2y, int &f3y, int &f4y, int &f5y, int &f6y, int &f7y, int &f8y, int &f9y, int &f10y, int &f11y, int &f12y, int &f13y, int &f14y, int &f15y, int &ran1x, int &ran2x, int &ran3x, int &ran4x, int &ran5x, int &ran6x, int &ran7x, int &ran8x, int &ran9x, int &ran10x, int &ran11x, int &ran12x, int &ran13x, int &ran14x, int &ran15x);
int main()
{
    char maze[29][92];
    // variables for car coodinates
    int carX = 23;
    int carY = 56;
    int car1X = 24;
    int car1Y = 56;
    // variables for coordinates of man
    int man1x = 21;
    int man1y = 3;
    int man2x = 22;
    int man2y = 3;
    int man3x = 23;
    int man3y = 3;
    int man4x = 24;
    int man4y = 3;
    int result = 0;
    int array[4];
    int endx = 24;
    // variables for the random bombs
    int ran1y = 4;
    int ran2y = 9;
    int ran3y = 14;
    int ran4y = 19;
    int ran5y = 24;
    int ran6y = 29;
    int ran7y = 34;
    int ran8y = 39;
    int ran9y = 44;
    int ran10y = 49;
    int ran11y = 54;
    int ran12y = 59;
    int ran13y = 64;
    int ran14y = 69;
    int ran15y = 74;
    // variables for the y coordinates of random bombs
    int f1y = 5;
    int f2y = 10;
    int f3y = 15;
    int f4y = 20;
    int f5y = 25;
    int f6y = 30;
    int f7y = 35;
    int f8y = 40;
    int f9y = 45;
    int f10y = 50;
    int f11y = 55;
    int f12y = 60;
    int f13y = 65;
    int f14y = 70;
    int f15y = 75;

    int w = 0, x = 0, y = 0, v = 0;
    // variables for the random bombs
    int ran1x = 2;
    int ran2x = 2;
    int ran3x = 2;
    int ran4x = 2;
    int ran5x = 2;
    int ran6x = 2;
    int ran7x = 2;
    int ran8x = 2;
    int ran9x = 2;
    int ran10x = 2;
    int ran11x = 2;
    int ran12x = 2;
    int ran13x = 2;
    int ran14x = 2;
    int ran15x = 2;
    int count = 3;
    int check = 0;

    int score = 0;
    int i = 0;
    bool r = false;
    bool c = false;

    system("cls");
    SetConsoleTextAttribute(color, 4);
    title();
    getch();
    system("cls");
    while (true)
    {
        system("cls");
        coordinates(carX, carY, car1X, car1Y, man1x, man2x, man3x, man4x, man1y, man2y, man3y, man4y, result);
        gotoxy(5, 10);
        cout << " ------------------------------------ ";
        gotoxy(6, 10);
        cout << " |        DARK DEVIL GAME           | ";
        gotoxy(7, 10);
        cout << " ------------------------------------";
        SetConsoleTextAttribute(color, 5);
        gotoxy(9, 10);
        cout << "1. Start Game";
        gotoxy(10, 10);
        cout << "2. Instructions";
        gotoxy(11, 10);
        cout << "3. Quit";
        gotoxy(13, 10);
        int op;
        cout << "Select option: ";
        cin >> op;
        if (op == 1)
        {
            int i = 0;
            system("cls");
            // to load the maze
            loadmaze(maze);
            // to print the maze

            ResetCoR(w, x, y, v);
            SetConsoleTextAttribute(color, 3);
            printmaze(maze);
            // srand(time(0));
            count = 3;
            while (true)
            {

                if (i > 0)
                {
                    i++;
                }
                if (i == 8)
                {
                    halfman(man3x, man3y, man4x, man4y);
                    i = 0;
                }
                int b = 100;

                check = random(man1x, w, x, y, v, ran1x, ran2x, ran3x, ran4x, ran5x, ran6x, ran7x, ran8x, ran9x, ran10x, ran11x, ran12x, ran13x, ran14x, ran15x, ran1y, ran2y, ran3y, ran4y, ran5y, ran6y, ran7y, ran8y, ran9y, ran10y, ran11y, ran12y, ran13y, ran14y, ran15y, f1y, f2y, f3y, f4y, f5y, f6y, f7y, f8y, f9y, f10y, f11y, f12y, f13y, f14y, f15y, endx, check);

                Sleep(b);

                SetConsoleTextAttribute(color, 6);
                movecar(carY, carX, car1X, car1Y);
                if (kbhit())
                {
                    char ch = getch();
                    if (ch == 'w')
                    {
                        jump(man1x, man2x, man3x, man4x, man1y, man2y, man3y, man4y);
                    }
                    if (ch == 'd')
                    {
                        right(man1x, man2x, man3x, man4x, man1y, man2y, man3y, man4y);
                    }

                    if (ch == 'a')
                    {
                        left(man1x, man2x, man3x, man4x, man1y, man2y, man3y, man4y);
                    }
                }
                food(score, man1x, man1y, maze);
                c = collideobjects(man1x, man1y, f1y, f2y, f3y, f4y, f5y, f6y, f7y, f8y, f9y, f10y, f11y, f12y, f13y, f14y, f15y, ran1x, ran2x, ran3x, ran4x, ran5x, ran6x, ran7x, ran8x, ran9x, ran10x, ran11x, ran12x, ran13x, ran14x, ran15x);
                r = collide(man3y, man4y, carY, car1Y);
                if (r == true || c == true)
                {
                    count = count - 1;
                    i = 1;
                    int positionx = 21;
                    int positiony = 86;

                    gotoxy(positionx, positiony);
                    cout << count;
                    if (count == 0)
                    {
                        getch();
                        break;
                    }
                }
            }
        }
        if (op == 2)
        {
            system("cls");
            instructions();
            getch();
        }
        if (op == 3)
        {
            exit();
        }
    }
}
// function to load the maze from the file into the array.........
void loadmaze(char maze[][92])
{
    int z = 0;
    string line;
    fstream f;
    f.open("maze.txt", ios::in);
    while (!(f.eof()))
    {
        getline(f, line);
        for (int i = 0; i < line.length(); i++)
        {
            maze[z][i] = line[i];
        }
        z++;
    }
    f.close();
}
// functtion to print the maze on the console.........
void printmaze(char maze[][92])
{
    for (int i = 0; i < 29; i++)
    {
        for (int j = 0; j < 93; j++)
        {
            cout << maze[i][j];
        }
        cout << endl;
    }
}
// function to move cars.......
void movecar(int &carY, int &carX, int &car1X, int &car1Y)
{
    if (carY - 1 != 0)
    {
        int y = carY - 1;
        int y2 = car1Y - 1;
        gotoxy(carX, carY - 1);
        cout << "1!!!!!!1";
        carY = carY + 7;
        gotoxy(carX, carY);
        cout << ' ';
        carY = y;
        gotoxy(car1X, car1Y - 1);
        cout << "_@____@_";
        car1Y = y2;
    }
    else
    {
        gotoxy(carX, carY);
        cout << "        ";
        gotoxy(car1X, car1Y);
        cout << "_________";
        carX = 23;
        carY = 69;
        car1X = 24;
        car1Y = 69;
    }
}
// function to move the man up.....
void jump(int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y)
{
    int c = man2y + 1;
    bool wallcheck = false;
    int wallx = 22;
    int wally = 74;
    for (int i = 0; i <= 8; i++)
    {
        if (c == wally)
        {
            wallcheck = true;
        }
        c++;
    }
    if (wallcheck == false)
    {

        gotoxy(man1x, man1y);
        cout << "   ";
        gotoxy(man2x, man2y);
        cout << "   ";
        gotoxy(man3x, man3y);
        cout << "   ";
        gotoxy(man4x, man4y);
        cout << "___";
        // move up........
        gotoxy(man1x - 2, man1y);
        cout << " O ";
        man1x = man1x - 2;
        gotoxy(man2x - 2, man2y);
        cout << "/|\\";
        man2x = man2x - 2;
        gotoxy(man3x - 2, man3y);
        cout << " | ";
        man3x = man3x - 2;
        gotoxy(man4x - 2, man4y);
        cout << "/ \\";
        man4x = man4x - 2;
        // moe right........
        gotoxy(man1x, man1y);
        cout << "   ";
        gotoxy(man2x, man2y);
        cout << "   ";
        gotoxy(man3x, man3y);
        cout << "   ";
        gotoxy(man4x, man4y);
        cout << "   ";
        gotoxy(man1x, man1y + 9);
        cout << " O ";
        man1y = man1y + 9;
        gotoxy(man2x, man2y + 9);
        cout << "/|\\";
        man2y = man2y + 9;
        gotoxy(man3x, man3y + 9);
        cout << " | ";
        man3y = man3y + 9;
        gotoxy(man4x, man4y + 9);
        cout << "/ \\";
        man4y = man4y + 9;
        // move down........
        gotoxy(man1x, man1y);
        cout << "   ";
        gotoxy(man2x, man2y);
        cout << "   ";
        gotoxy(man3x, man3y);
        cout << "   ";
        gotoxy(man4x, man4y);
        cout << "   ";
        gotoxy(man1x + 2, man1y);
        cout << " O ";
        man1x = man1x + 2;
        gotoxy(man2x + 2, man2y);
        cout << "/|\\";
        man2x = man2x + 2;
        gotoxy(man3x + 2, man3y);
        cout << " | ";
        man3x = man3x + 2;
        gotoxy(man4x + 2, man4y);
        cout << "/_\\";
        man4x = man4x + 2;
    }
}
// function to move the man left...
void right(int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y)
{
    int wallx = 22;
    int wally = 74;

    if (man2y != wally)
    {
        gotoxy(man1x, man1y);
        cout << ' ';
        gotoxy(man2x, man2y);
        cout << ' ';
        gotoxy(man3x, man3y);
        cout << ' ';
        gotoxy(man4x, man4y);
        cout << ' ';
        gotoxy(man1x, man1y + 1);
        cout << " O ";
        man1y++;
        gotoxy(man2x, man2y + 1);
        cout << "/|\\";
        man2y++;
        gotoxy(man3x, man3y + 1);
        cout << " | ";
        man3y++;
        gotoxy(man4x, man4y + 1);
        cout << "/ \\";
        gotoxy(man4x, man4y);
        cout << "_/_";
        man4y++;
    }
}
// function to move the man left....
void left(int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y)
{
    int wallx = 22;
    int wally = 1;
    if (man2y != wally)
    {
        gotoxy(man1x, man1y);
        cout << "   ";
        gotoxy(man2x, man2y);
        cout << "   ";
        gotoxy(man3x, man3y);
        cout << "   ";
        gotoxy(man4x, man4y);
        cout << "___";
        gotoxy(man1x, man1y - 1);
        cout << " O ";
        man1y--;
        gotoxy(man2x, man2y - 1);
        cout << "/|\\";
        man2y--;
        gotoxy(man3x, man3y - 1);
        cout << " | ";
        man3y--;
        gotoxy(man4x, man4y - 1);
        cout << "/_\\";
        man4y--;
    }
}
// function for the collision process.......
bool collide(int &man3y, int &man4y, int &carY, int &car1Y)
{
    if ((man3y + 1) == carY && (man4y + 1) == car1Y)
    {

        return true;
    }
    return false;
}
// function for the instructions of the users
void instructions()
{
    gotoxy(5, 10);
    cout << "Instructions" << endl;
    gotoxy(6, 10);
    cout << "----------------" << endl;
    gotoxy(7, 10);
    cout << "Just move the man." << endl;
    gotoxy(8, 10);
    cout << "                                          " << endl;
    gotoxy(9, 10);
    cout << "Press w to jump the man over the car." << endl;
    gotoxy(10, 10);
    cout << "Press a to move the man left." << endl;
    gotoxy(11, 10);
    cout << "Press d to move the man right." << endl;
    gotoxy(12, 10);
    cout << "Eat the points to increase your marks." << endl;
    gotoxy(13, 10);
    cout << "                                           " << endl;
    gotoxy(14, 10);
    cout << "Press any key to go back to menu" << endl;
}
// function to exit the game
void exit()
{
    cout << "\n\n\n\n\n\n\n\n\n\n\n";
    cout << "             Exiting..........";
    exit(0);
}
// function to print the name of the game on the console
void title()
{
    string line;
    fstream f;
    f.open("title.txt", ios::in);
    while (!(f.eof()))
    {
        getline(f, line);
        cout << line << endl;
    }
    f.eof();
}
// function to produce  random fires
int random(int &man1x, int &w, int &x, int &y, int &v, int &ran1x, int &ran2x, int &ran3x, int &ran4x, int &ran5x, int &ran6x, int &ran7x, int &ran8x, int &ran9x, int &ran10x, int &ran11x, int &ran12x, int &ran13x, int &ran14x, int &ran15x, int &ran1y, int &ran2y, int &ran3y, int &ran4y, int &ran5y, int &ran6y, int &ran7y, int &ran8y, int &ran9y, int &ran10y, int &ran11y, int &ran12y, int &ran13y, int &ran14y, int &ran15y, int &f1y, int &f2y, int &f3y, int &f4y, int &f5y, int &f6y, int &f7y, int &f8y, int &f9y, int &f10y, int &f11y, int &f12y, int &f13y, int &f14y, int &f15y, int &endx, int &check)
{

    if (w == 1 || x == 1 || y == 1 || v == 1)
    {
        if (ran1x != endx)
        {

            gotoxy(ran1x, ran1y);
            cout << ' ';
            ran1x++;
            gotoxy(ran1x, ran1y);
            cout << 'o';
            if (ran1x + 1 == man1x && ran1y + 1 == f1y)
            {
                check++;
                return check;
            }
        }
        else
        {

            gotoxy(ran1x, ran1y);
            cout << '_';
            ran1x = 2;
            ResetCoR(w, x, y, v);
        }
    }

    if (w == 2 || x == 2 || y == 2 || v == 2)
    {
        if (ran2x != endx)
        {
            gotoxy(ran2x, ran2y);
            cout << ' ';
            ran2x++;
            gotoxy(ran2x, ran2y);
            cout << 'o';
            if (ran2x + 1 == man1x && ran2y + 1 == f2y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran2x, ran2y);
            cout << '_';
            ran2x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 3 || x == 3 || y == 3 || v == 3)
    {
        if (ran3x != endx)
        {

            gotoxy(ran3x, ran3y);
            cout << ' ';
            ran3x++;
            gotoxy(ran3x, ran3y);
            cout << 'o';
            if (ran3x + 1 == man1x && ran3y + 1 == f3y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran3x, ran3y);
            cout << '_';
            ran3x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 4 || x == 4 || y == 4 || v == 4)
    {
        if (ran4x != endx)
        {

            gotoxy(ran4x, ran4y);
            cout << ' ';
            ran4x++;
            gotoxy(ran4x, ran4y);
            cout << 'o';
            if (ran4x + 1 == man1x && ran4y + 1 == f4y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran4x, ran4y);
            cout << '_';
            ran4x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 5 || x == 5 || y == 5 || v == 5)
    {
        if (ran5x != endx)
        {

            gotoxy(ran5x, ran5y);
            cout << ' ';
            ran5x++;
            gotoxy(ran5x, ran5y);
            cout << 'o';
            if (ran5x + 1 == man1x && ran5y + 1 == f5y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran5x, ran5y);
            cout << '_';
            ran5x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 6 || x == 6 || y == 6 || v == 6)
    {

        if (ran6x != endx)
        {
            gotoxy(ran6x, ran6y);
            cout << ' ';
            ran6x++;
            gotoxy(ran6x, ran6y);
            cout << 'o';
            if (ran6x + 1 == man1x && ran6y + 1 == f6y)
            {
                check++;
                return check;
            }
        }

        else
        {
            gotoxy(ran6x, ran6y);
            cout << '_';
            ran6x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 7 || x == 7 || y == 7 || v == 7)
    {
        if (ran7x != endx)
        {
            gotoxy(ran7x, ran7y);
            cout << ' ';
            ran7x++;
            gotoxy(ran7x, ran7y);
            cout << 'o';
            if (ran7x + 1 == man1x && ran7y + 1 == f7y)
            {
                check++;
                return check;
            }
        }

        else
        {
            gotoxy(ran7x, ran7y);
            cout << '_';
            ran7x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 8 || x == 8 || y == 8 || v == 8)
    {
        if (ran8x != endx)
        {

            gotoxy(ran8x, ran8y);
            cout << ' ';
            ran8x++;
            gotoxy(ran8x, ran8y);
            cout << 'o';
            if (ran8x + 1 == man1x && ran8y + 1 == f8y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran8x, ran8y);
            cout << '_';
            ran8x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 9 || x == 9 || y == 9 || v == 9)
    {
        if (ran9x != endx)
        {

            gotoxy(ran9x, ran9y);
            cout << ' ';
            ran9x++;
            gotoxy(ran9x, ran9y);
            cout << 'o';
            if (ran9x + 1 == man1x && ran9y + 1 == f9y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran9x, ran9y);
            cout << '_';
            ran9x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 10 || x == 10 || y == 10 || v == 10)
    {

        if (ran10x != endx)
        {
            gotoxy(ran10x, ran10y);
            cout << ' ';
            ran10x++;
            gotoxy(ran10x, ran10y);
            cout << 'o';
            if (ran10x + 1 == man1x && ran10y + 1 == f10y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran10x, ran10y);
            cout << '_';
            ran10x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 11 || x == 11 || y == 11 || v == 11)
    {
        if (ran11x != endx)
        {

            gotoxy(ran11x, ran11y);
            cout << ' ';
            ran11x++;
            gotoxy(ran11x, ran11y);
            cout << 'o';

            if (ran11x + 1 == man1x && ran11y + 1 == f11y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran11x, ran11y);
            cout << '_';
            ran11x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 12 || x == 12 || y == 12 || v == 12)
    {
        if (ran12x != endx)
        {

            gotoxy(ran12x, ran12y);
            cout << ' ';
            ran12x++;
            gotoxy(ran12x, ran12y);
            cout << 'o';
            if (ran12x + 1 == man1x && ran12y + 1 == f12y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran12x, ran12y);
            cout << '_';
            ran12x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 13 || x == 13 || y == 13 || v == 13)
    {
        if (ran13x != endx)
        {

            gotoxy(ran13x, ran13y);
            cout << ' ';
            ran13x++;
            gotoxy(ran13x, ran13y);
            cout << 'o';
            if (ran13x + 1 == man1x && ran13y + 1 == f13y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran13x, ran13y);
            cout << '_';
            ran13x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 14 || x == 14 || y == 14 || v == 14)
    {
        if (ran14x != endx)
        {

            gotoxy(ran14x, ran14y);
            cout << ' ';
            ran14x++;
            gotoxy(ran14x, ran14y);
            cout << 'o';
            if (ran14x + 1 == man1x && ran14y + 1 == f14y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran14x, ran14y);
            cout << '_';
            ran14x = 2;
            ResetCoR(w, x, y, v);
        }
    }
    if (w == 15 || x == 15 || y == 15 || v == 15)
    {
        if (ran15x != endx)
        {

            gotoxy(ran15x, ran15y);
            cout << ' ';
            ran15x++;
            gotoxy(ran15x, ran15y);
            cout << 'o';
            if (ran15x + 1 == man1x && ran15y + 1 == f15y)
            {
                check++;
                return check;
            }
        }
        else
        {
            gotoxy(ran15x, ran15y);
            cout << '_';
            ran15x = 2;
            ResetCoR(w, x, y, v);
        }
    }
}
void ResetCoR(int &w, int &x, int &y, int &v)
{
    for (int i = 0; i < 4; i++)
    {
        int result = rand() % 15;
        if (i == 0)
        {
            w = result;
        }
        if (i == 1)
        {
            x = result;
        }
        if (i == 2)
        {
            y = result;
        }
        if (i == 3)
        {
            v = result;
        }
    }
}

// function for the food palets.....
void food(int &score, int &man1x, int &man1y, char maze[][92])
{

    int food1x = 21;
    int food1y = 3;
    int food2x = 21;
    int food2y = 8;
    int food3x = 21;
    int food3y = 14;
    int food4x = 21;
    int food4y = 20;
    int food5x = 21;
    int food5y = 28;
    int food6x = 21;
    int food6y = 34;
    int food7x = 21;
    int food7y = 38;
    int food8x = 21;
    int food8y = 44;
    int food9x = 21;
    int food9y = 51;
    int food10x = 21;
    int food10y = 56;
    int food11x = 21;
    int food11y = 62;
    int food12x = 21;
    int food12y = 68;
    int food13x = 21;
    int food13y = 73;
    int food14x = 21;
    int food14y = 77;

    int scorex = 8;
    int scorey = 87;
    if (maze[man1x][man1y] == '.')
    {
        maze[man1x][man1y] = ' ';
        score++;
        food1y--;
        gotoxy(food1x, food1y);
        cout << '.';
        maze[food1x][food1y] = '.';
    }

    if (man1y == food2y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food2y--;
        gotoxy(food2x, food2y);
        cout << '.';
        maze[food2x][food2y] = '.';
    }
    if (man1y == food3y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food3y--;
        gotoxy(food3x, food3y);
        cout << '.';
        maze[food3x][food3y] = '.';
    }

    if (man1y == food4y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food4y--;
        gotoxy(food4x, food4y);
        cout << '.';
        maze[food4x][food4y] = '.';
    }

    if (man1y == food5y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food5y--;
        gotoxy(food5x, food5y);
        cout << '.';
        maze[food5x][food5y] = '.';
    }

    if (man1y == food6y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food6y--;
        gotoxy(food6x, food6y);
        cout << '.';
        maze[food6x][food6y] = '.';
    }

    if (man1y == food7y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food7y--;
        gotoxy(food7x, food7y);
        cout << '.';
        maze[food7x][food7y] = '.';
    }

    if (man1y == food8y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food8y--;
        gotoxy(food8x, food8y);
        cout << '.';
        maze[food8x][food8y] = '.';
    }

    if (man1y == food9y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food9y--;
        gotoxy(food9x, food9y);
        cout << '.';
        maze[food9x][food9y] = '.';
    }

    if (man1y == food10y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food10y--;
        gotoxy(food10x, food10y);
        cout << '.';
        maze[food10x][food10y] = '.';
    }

    if (man1y == food11y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food11y--;
        gotoxy(food11x, food11y);
        cout << '.';
        maze[food11x][food11y] = '.';
    }

    if (man1y == food12y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food12y--;
        gotoxy(food12x, food12y);
        cout << '.';
        maze[food12x][food12y] = '.';
    }

    if (man1y == food13y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food13y--;
        gotoxy(food13x, food13y);
        cout << '.';
        maze[food13x][food13y] = '.';
    }

    if (man1y == food14y)
    {
        maze[man1x][man1y] = ' ';
        score++;
        food14y--;
        gotoxy(food14x, food14y);
        cout << '.';
        maze[food14x][food14y] = '.';
    }

    gotoxy(scorex, scorey);
    cout << score;
}
// function to print the half man....
void halfman(int &man3x, int &man3y, int &man4x, int &man4y)
{
    SetConsoleTextAttribute(color, 3);
    gotoxy(man3x, man3y);
    cout << " | ";
    gotoxy(man4x, man4y);
    cout << "/_\\";
}
void coordinates(int &carX, int &carY, int &car1X, int &car1Y, int &man1x, int &man2x, int &man3x, int &man4x, int &man1y, int &man2y, int &man3y, int &man4y, int &result)
{
    carX = 23;
    carY = 56;
    car1X = 24;
    car1Y = 56;
    man1x = 21;
    man1y = 3;
    man2x = 22;
    man2y = 3;
    man3x = 23;
    man3y = 3;
    man4x = 24;
    man4y = 3;
    result = 0;
}
bool collideobjects(int &man1x, int &man1y, int &f1y, int &f2y, int &f3y, int &f4y, int &f5y, int &f6y, int &f7y, int &f8y, int &f9y, int &f10y, int &f11y, int &f12y, int &f13y, int &f14y, int &f15y, int &ran1x, int &ran2x, int &ran3x, int &ran4x, int &ran5x, int &ran6x, int &ran7x, int &ran8x, int &ran9x, int &ran10x, int &ran11x, int &ran12x, int &ran13x, int &ran14x, int &ran15x)
{

    int c = man1y;
    int d = c + 1;
    int e = d + 1;
    if (((man1x == ran1x) && (c == f1y)) || ((man1x == ran1x) && (d == f1y)) || ((man1x == ran1x) && (e == f1y)))
    {
        ran1x = 2;
        return true;
    }
    if (((man1x == ran2x) && (c == f2y)) || ((man1x == ran2x) && (d == f2y)) || ((man1x == ran2x) && (e == f2y)))
    {
        ran2x = 2;
        return true;
    }
    if (((man1x == ran3x) && (c == f3y)) || ((man1x == ran3x) && (d == f3y)) || ((man1x == ran3x) && (e == f3y)))
    {
        ran3x = 2;
        return true;
    }
    if (((man1x == ran4x) && (c == f4y)) || ((man1x == ran4x) && (d == f4y)) || ((man1x == ran4x) && (e == f4y)))
    {
        ran4x = 2;
        return true;
    }
    if (((man1x == ran5x) && (c == f5y)) || ((man1x == ran5x) && (d == f5y)) || ((man1x == ran5x) && (e == f5y)))
    {
        ran5x = 2;
        return true;
    }
    if (((man1x == ran6x) && (c == f6y)) || ((man1x == ran6x) && (d == f6y)) || ((man1x == ran6x) && (e == f6y)))
    {
        ran6x = 2;
        return true;
    }
    if (((man1x == ran7x) && (c == f7y)) || ((man1x == ran7x) && (d == f7y)) || ((man1x == ran7x) && (e == f7y)))
    {
        ran7x = 2;
        return true;
    }
    if (((man1x == ran8x) && (c == f8y)) || ((man1x == ran8x) && (d == f8y)) || ((man1x == ran8x) && (e == f8y)))
    {
        ran8x = 2;
        return true;
    }
    if (((man1x == ran9x) && (c == f9y)) || ((man1x == ran9x) && (d == f9y)) || ((man1x == ran9x) && (e == f9y)))
    {
        ran9x = 2;
        return true;
    }
    if (((man1x == ran10x) && (c == f10y)) || ((man1x == ran10x) && (d == f10y)) || ((man1x == ran10x) && (e == f10y)))
    {
        ran10x = 2;
        return true;
    }
    if (((man1x == ran11x) && (c == f11y)) || ((man1x == ran11x) && (d == f11y)) || ((man1x == ran11x) && (e == f11y)))
    {
        ran11x = 2;
        return true;
    }
    if (((man1x == ran12x) && (c == f12y)) || ((man1x == ran12x) && (d == f12y)) || ((man1x == ran12x) && (e == f12y)))
    {
        ran12x = 2;
        return true;
    }
    if (((man1x == ran13x) && (c == f13y)) || ((man1x == ran13x) && (d == f13y)) || ((man1x == ran13x) && (e == f13y)))
    {
        ran13x = 2;
        return true;
    }
    if (((man1x == ran14x) && (c == f14y)) || ((man1x == ran14x) && (d == f14y)) || ((man1x == ran14x) && (e == f14y)))
    {
        ran14x = 2;
        return true;
    }
    if (((man1x == ran15x) && (c == f15y)) || ((man1x == ran15x) && (d == f15y)) || ((man1x == ran15x) && (e == f15y)))
    {
        ran15x = 2;
        return true;
    }
    return false;
}