#include <iostream>
using namespace std;
int n;
void countpossumneg(int a[20]);
main()
{
    int a[20];
    cout << "Enter the number of times u want to enter value: ";
    cin >> n;
    countpossumneg(a);
}
void countpossumneg(int a[20])
{
    int count = 0;
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        cout << "Enter values: " << endl;
        cin >> a[i];
        if (a[i] > 0)
        {
            count++;
        }
        if (a[i] < 0)
        {

            sum = sum + a[i];
        }
    }
    cout << "Positive count: " << count << endl;
    cout << "Negative sum: " << sum << endl;
}
