#include<iostream>
using namespace std;
 double mysteryfunc(int n);
main(){
int n;
cout<<"Enter a number: "<<endl;
cin>>n;
cout<<mysteryfun(n);
}
 double mysteryfunc(n){
    for(int i=n;i!=0;i=i/10){
       
    }
 }
