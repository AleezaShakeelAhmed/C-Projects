#include<iostream>
#include<conio.h>
using namespace std;
string flip(string a);
int main()
{
    string a;
   cout<<"Enter a string: "<<endl;
   cin>>a;
    cout<<flip(a);
    
}
string flip(string a){
int length=a.size();
if(length<2){
    return "incompatible";
}
else if(a[0]==a[length-1]){
    return "Two's pair";
}
else if(length>=2){
    char temp;
     temp=a[0];
    
    a[0]=a[length-1];
    a[length-1]=temp;
    return a;

}
}


