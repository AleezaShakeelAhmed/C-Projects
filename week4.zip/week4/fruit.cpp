#include<iostream>
#include<conio.h>
using namespace std;
string fruit[4]={"peach","apple","guava"," watermelon"};
int price[4]={60,70,40,30};
int bill(string name,int kg);


int main()
{
    string name;
    int kg;
    cout<<"Enter the name of the fruit: "<<endl;
    cin>>name;
    cout<<"Enter the quantity of the fruit in kgs: "<<endl;
    cin>>kg;
    cout<<bill(name,kg);
    
}
int bill(string name,int kg){
    int a;
   for (int i = 0; i < 4; i++)
   {
       if(name==fruit[i]){
           a=i;
           break;
       }
   }
    return  price[a]*kg;

   
   
}