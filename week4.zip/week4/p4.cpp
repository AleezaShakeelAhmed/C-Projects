#include<iostream>
#include<conio.h>
using namespace std;
void spelling(string a);
int main()
{
    string a;
     cout<<"Enter a string: "<<endl;
   cin>>a;
   spelling(a); 
}
void spelling(string a){
  string b;
   int length=a.size();
   for(int i=0;i<length;i++){
       b=b+a[i];
       cout<<b<<" ";
   }

}
