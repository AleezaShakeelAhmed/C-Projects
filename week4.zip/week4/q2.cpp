#include <iostream>
using namespace std;
int n;
void sevenboom(int a[20]);

main()
{
    int a[20];

    cout << "Enter number of times u want to enter the value: " << endl;
    cin >> n;
    sevenboom(a);
}
void sevenboom(int a[20])
{
 int count = 0;

    for (int i = 0; i < n; i++)
    {
        cout << "Enter value: " << endl;

        cin >> a[i];
        for (int j = a[i]; j != 0; j = j / 10)
        {

            if (j % 10 == 7)
            {
                count++;
            }
        }
    }
    if (count >= 1)
    {
        cout << "BOOM!";
    }
    else if (count < 1)
    {
        cout<<"there is no seven in the array";
    }
}
