#include <iostream>
#include <conio.h>
using namespace std;
bool iscorrectaliases(string a[10], string b[10]);
int main()
{
    string a[10];
    string b[10];
    cout << iscorrectaliases(a, b);
}
bool iscorrectaliases(string a[10], string b[10])
{
    int num;
    string d;
    char c;
    cout << "Enter the number of names you want to enter in both arrays: " << endl;
    cin >> num;
    int check = 0;
    cout<<"1st Array \n\n";
    cin.ignore();
    for (int i = 0; i < num; i++)
    {
        cout << "Enter " << i + 1 << "Name: ";
        getline(cin, a[i]);
    }
     cout<<"2nd Array \n\n";
    //  cin.ignore();
    for (int i = 0; i < num; i++)
    {
        cout << "Enter " << i + 1 << "Name: ";
        getline(cin, b[i]);
    }
    for (int i = 0; i < num; i++)
    {
        int length = b[i].size();
        string fajar = b[i];

        d = a[i];
        // c = d[0];
        int idx = 0;
        for (int j = 0; j < length; j++)
        {
            if (fajar[j] == ' ')
            {
                idx = ++j;
                break;
            }
        }
        if (fajar[idx] == d[0] && fajar[0] == d[0])
        {
            check++;
        }
    }
    if (check == num)
    {
        return true;
    }
    else
    {
        return false;
    }
}
