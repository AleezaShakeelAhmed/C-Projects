#include<iostream>
using namespace std;
void junctionorself(int n);
main(){
int n;
cout<<"Enter a number: "<<endl;
cin>>n;
cout<< junctionorself(n);
}
void junctionorself(int n){
for(int i=1;)
}
