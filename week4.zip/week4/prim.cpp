#include <iostream>
using namespace std;
int primorial(int n);
bool isprime(int n);
main()
{
    int n;
    cout << "Enter a number: " << endl;
    cin >> n;
    cout << primorial(n);
}
bool isprime(int n)
{
    for (int i = 2; i < n; i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }
    return true;
}
int primorial(int n)
{
    int sum;
    for (int i = 1; i <= n; i++)
    {
        if (isprime(n) == true)
        {
            sum = sum * n;
        }
    }
}
