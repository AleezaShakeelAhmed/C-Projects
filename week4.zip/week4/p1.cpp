#include <iostream>
using namespace std;
int str(string a, string b);

main()
{
  string a;
  string b;
  cout << "Enter the first string: " << endl;
  cin >> a;
  cout << "Enter the second string: " << endl;
  cin >> b;
  cout << str(a, b);
}
int str(string a, string b)
{
  int count = 0;
  int len = a.size();
  int l = b.size();

  if (len < l || len == l)
  {
    for (int i = 0; i < len; i++)
    {
      if (a[i] == b[i])
      {
        count++;
      }
    }
    return count;
  }
  if (l < len)
  {
    for (int i = 0; i < l; i++)
    {
      if (a[i] == b[i])
      {
        count++;
      }
    }
    return count;
  }
}