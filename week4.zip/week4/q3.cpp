#include <iostream>
using namespace std;
int n;
int majorsum(int a[20]);
main()
{
    int a[20];
    cout << "Enter number of times u want to enter the value: " << endl;
    cin >> n;
    cout << majorsum(a);
}
int majorsum(int a[20])
{
    int z;
    int s = 0;
    int b = 0;
    int c = 0;
    int x = 0;
    int y = 0;

    for (int i = 0; i < n; i++)
    {
        cout << "Enter value: " << endl;
        cin >> a[i];
        if (a[i] > 0)
        {
            s++;
            x = x + a[i];
        }
        else if (a[i] < 0)
        {
            b++;
            y = y + a[i];
             z=y*(-1);
        }
        else if (a[i] == 0)
        {
            c++;
        }
    }
    if (c > s && c > b)
    {
        return c;
    }
    else if (z > x)
    {
        return y;
    }
    else if (x > z)
    {
        return x;
    }
}
