#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
    string name1, name2, word, newa;
    char c;
    system("cls");
    cout << "****************************************************************" << endl;
    cout << "******            WELCOME TO HANGMAN GAME                 ******" << endl;
    cout << "****************************************************************" << endl;
    cout << "                                                                " << endl;
    cout << "                                                                " << endl;
    cout << "RULES :   YOU HAVE ONLY THREE TRIES TO GUESS THE WORD BY GUESSING RANDOM LETTERS" << endl;
    cout << "                                                                " << endl;
    cout << "BE SPECIFIC IN LOWER/UPPER CASE LETTERS." << endl;
    cout << "                                                                " << endl;
    cout << "                                                                " << endl;
    cout << "Player 1! Enter your name: " << endl;
    cin >> name1;
    cout << "Player 2! Enter your name: " << endl;
    cin >> name2;
    system("cls");
    cout << name1 << "  enter the word :" << endl;
    cin >> word;
    system("cls");

    int length = word.size();

    int a = 2;
    for (int i = 0; i < length; i++)
    {
        newa[i] = '_';
    }

    // game running process
    int winningcheck = 0;
    int check = 0;
    while (a >= 0)
    {
        system("cls");
        while (true)
        {
            cout << name2 << "  enter the guess letter: " << endl;
            cin >> c;
            for (int i = 0; i < length; i++)
            {
                if (word[i] == c)
                {
                    newa[i] = c;
                    cout << newa << endl;
                    check = 1;
                     winningcheck++;
                    break;
                }
            }
            if (winningcheck == length)
            {
                check = 2;
                break;
            }

            if (check == 0)
            {
                cout << "Wrong guess!" << endl;

                cout << name2 << " You have " << a << " tries left." << endl;
                break;
            }
            else if (check == 1)
            {
                check = 0;
                continue;
            }
        }
        if (check == 2)
        {
            break;
        }
        a--;
    }
    if (check != 2)
    {
        cout << "Wrong guess!" << endl;

        cout << "You have "
             << "0"
             << " tries left." << endl;
        cout << "PLAYER 2! YOU HAVE LOST!" << endl;
        cout << "             ******************************************" << endl;
        cout << "                                    *" << endl;
        cout << "                                    *" << endl;
        cout << "                                   ***" << endl;
        cout << "                                  *    *" << endl;
        cout << "                                   ***" << endl;
        cout << "                                   ***" << endl;
        cout << "                                  * * *" << endl;
        cout << "                                *   *   *" << endl;
        cout << "                              *     *     *" << endl;
        cout << "                                    *" << endl;
        cout << "                                    *" << endl;
        cout << "                                   *  * " << endl;
        cout << "                                  *    * " << endl;
        cout << "                                 *      * " << endl;
        cout << "                                *        * " << endl;
    }
    else
    {
        cout << "YOU WON!!!! :)";
    }
}
