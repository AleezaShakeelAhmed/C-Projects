#include <iostream>
using namespace std;
int countloneones(int n);
main()
{
    int n;
    cout << "Enter a number: " << endl;
    cin >> n;
    cout << countloneones(n);
}
int countloneones(int n)
{
    int count;
    for (int i = 1; i != 0; i = i / 10)
    {
        i = i % 10;
        if (i == 1)
        {
            count++;
        }
        
    }
    return count;
}
