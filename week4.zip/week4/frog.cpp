#include <iostream>
#include <conio.h>
using namespace std;
void jumpingfrog(int number, int array[10]);
int main()
{
    int number;
    int array[10];

    jumpingfrog(number, array);
}
void jumpingfrog(int number, int array[10])
{
    int count = 1;
    cout << "Enter number: " << endl;
    cin >> number;
    for (int i = 0; i < number; i++)
    {
        cout << "Enter the jump:" << endl;
        cin >> array[i];
    }
    int check=0;
    for (int i = 0; i < number; i++)
    {
        if (array[i] == 1)
        {
            count++;
        }
        else if (array[i] != 1 && array[i] != 0)
        {
            count--;
        }
        else if (array[i] == 0)
        {
            check=1;
            cout << "no chance:-(" << endl;
            break;
        }
    }
    if(check==0){
    cout << count;
    }
    
}
