#include <iostream>
#include <conio.h>
#include <string.h>
using namespace std;
int n;
string societyname(string a[]);
int main()
{
    
    string a[10];
    cout << "Enter the number of names: " << endl;
    cin >> n;
    cout<<societyname(a);
}
string societyname(string a[])
{
    string b, z;
    for (int i = 0; i < n; i++)
    {
        cout << "Enter string: " << endl;
        cin >> a[i];
        b = a[i];
        z = z + b[0];
    }

    return z;
}
