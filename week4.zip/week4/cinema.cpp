#include<iostream>
#include<conio.h>
using namespace std;
string name;
float discount(string movies[5]);
int main()
{    
string movies[5]={"gladiators","starwars","terminators","takinglives","tombriders"};
    cout<<"Enter the movie name :"<<endl;
    cin>>name;
    cout<<discount(movies);

}
float discount(string movies[5]){
    float disc,d;
    if(name==movies[0]||name==movies[2]||name==movies[4]){
       disc=500.0*(5/100.0);
       d=500.0-disc;
       return d;
       
    }
    else{
        disc=500.0*(10/100.0);
        d=500.0-disc;
        return d;
    }
}


