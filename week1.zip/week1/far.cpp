#include <iostream>
using namespace std;
main()
{
    float area, number, first, second, scf, pcf, fcf, lcf, spf, area1, x, y, z, w, a, b, c, ee,d;
    cout << "Enter  total farm area in acres: " << endl;
    cin >> area;
    cout << "Enter the number of vegetables you want to grow. You can enter only one or two: " << endl;
    cin >> number;
    if (number == 2)
    {
        cout << "Enter percentage of farmland of first vegetable for one acre: " << endl;
        cin >> first;
        cout << "Enter percentage of farmland of second vegetable for one acre: " << endl;
        cin >> second;
        cout << "Enter the seed cost price for one acre: " << endl;
        cin >> scf;
        cout << "Enter the plantation cost for one acre: " << endl;
        cin >> pcf;
        cout << "Enter the fertilizing cost for one acre: " << endl;
        cin >> fcf;
        cout << "Enter the labor cost for one acre: " << endl;
        cin >> lcf;
        cout << "Enter vegetable selling price per acre of the first vegetable: " << endl;
        cin >> spf;
        cout << "Enter vegetable selling price per acre of the second vegetable: " << endl;
        cin >> ee;
        area1 = first + second;
        x = scf * area1;
        y = pcf * area1;
        z = fcf * area1;
        w = lcf * area1;
        a = x + y + z + w;
        d=spf+ee;
        b = d * area1;
        c = b - a;

        cout << "Your total revenue is:" << b << endl;
        cout << "cost"
             << ":" << a << endl;
        if (b > a)
        {
            cout << "Profit." << endl;
        }
        else if (a > b)
        {
            cout << "Loss." << endl;
        }
    }
    else if (number == 1)
    {
        cout << "Enter the seed cost price for one acre: " << endl;
        cin >> scf;
        cout << "Enter the plantation cost  for one acre: " << endl;
        cin >> pcf;
        cout << "Enter the fertilizing cost for one acre: " << endl;
        cin >> fcf;
        cout << "Enter the labor cost of one acre: " << endl;
        cin >> lcf;
        cout << "Enter vegetable selling price per acre: " << endl;
        cin >> spf;
        x = scf * area;
        y = pcf * area;
        z = fcf * area;
        w = lcf * area;
        a = x + y + z + w;
        b = spf * area;
        c = b - a;
        cout << "Your total revenue is:" << b << endl;
        cout << "cost: " << a << endl;
        if (b > a)
        {
            cout << "Profit." << endl;
        }
        else if (a > b)
        {
            cout << "Loss." << endl;
        }
    }
}