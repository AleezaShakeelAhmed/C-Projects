#include<iostream>
using namespace std;
main(){
    string gender;
    float weight,wf,wn,hf,ff,b,a1,a2,a3,a4,a5,body_fat,body_fat_percentage,wm;
    cout<<"Enter yor gender: "<<endl;
    cin>>gender;
    if(gender=="female"){
        cout<<"Enter your body weight: "<<endl;
        cin>>weight;
        cout<<"Enter your wrist measurement at fullest point: "<<endl;
        cin>>wf;
        cout<<"Enter your waist measurement at navel: "<<endl;
        cin>>wn;
        cout<<"Enter your hip measurement at fullest point: "<<endl;
        cin>>hf;
        cout<<"Enter your forearm measurement at fullest point: "<<endl;
        cin>>ff;
        a1=(weight*0.732)+8.987;
        a2=wf/3.140;
        a3=wn*0.157;
        a4=hf*0.249;
        a5=ff*0.434;
        b=a1+a2-a3-a4+a5;
        body_fat=weight-b;
        body_fat_percentage=body_fat*100/weight;
        cout<<"Your body fat is: "<<body_fat<<'\n'<<"The percentage of your body fat is: "<<body_fat_percentage<<endl;
    }
    else if(gender=="male"){
        cout<<"Enter your body weight: "<<endl;
        cin>>weight;
        cout<<"Enter your wrist measurement: "<<endl;
        cin>>wm;
        a1=(weight*1.082)+94.42;
        a2=wm*4.15;
        b=a1-a2;
        body_fat=weight-b;
        body_fat_percentage=body_fat*100/weight;
        cout<<"Your body fat is: "<<body_fat<<'\n'<<"The percentage of your body fat is: "<<body_fat_percentage<<endl;

    }
}