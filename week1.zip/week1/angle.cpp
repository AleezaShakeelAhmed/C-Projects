#include<iostream>
using namespace std;
main(){
int a,b,c;
cout<<"Enter first angle of a triangle: "<<endl;
cin>>a;
cout<<"Enter second angle of a triangle: "<<endl;
cin>>b;
cout<<"Enter third angle of a triangle: "<<endl;
cin>>c;
if(a+b+c==180){
    cout<<"Valid triangle.";
}
else{
    cout<<"Invalid triangle.";
}

}