#include <iostream>
using namespace std;
main()
{
    float f;
    int n;
    cout << "Enter input in centigrades: " << endl;
    cin >> n;
    f = (n * 9.0 / 5.0) + 32;
    cout << "Temperature in fahrenheit is: " << f;
}