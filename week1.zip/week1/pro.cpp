#include<iostream> 
using namespace std;
main()
{
    int hours, days, workers, a, b, c, d, e,l;
    cout << "Enter hours which are needed to complete the task: " << endl;
    cin >> hours;
    cout << "Enter the days a firm has: " << endl;
    cin >> days;
    cout << "Enter total number of workers: " << endl;
    cin >> workers;
    a = days * workers;
    b = a * 10;
    c = b * 10 / 100;
    d = b - c;
    e = d - hours;
    if (hours < d)
    {
        l = d - hours;
        cout << "Yes!"
             << " " << l << " "
             << "hours left.";
    }
    else if (hours > d)
    {
        l = hours - d;
        cout << "Not enough time!"
             << " " << l << " "
             << "hours needed.";
    }
}
