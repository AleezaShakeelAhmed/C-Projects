#include<iostream>
#include<cmath>
using namespace std;
main(){
    int r,R;
    float v;
    cout<<"Enter radius: "<<endl;
    cin>>r;
    R=pow(r,3);
    v=4.0/3.0*3.14*R;
    cout<<"Volume of a sphere: "<<v;

}