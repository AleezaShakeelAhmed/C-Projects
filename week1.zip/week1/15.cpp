#include<iostream>
using namespace std;
main(){
    string pwd;
    cout<<"Enter a password: "<<endl;
    cin>>pwd;
    if(pwd=="s3cr3t!p@ssword"){
        cout<<"Welcome"<<endl;

    }
    else{
        cout<<"Wrong password!"<<endl;
    }
}