#include <iostream>
using namespace std;
main()
{
    float bgn, a;
    string season;
    cout << "Enter your budget: " << endl;
    cin >> bgn;
    cout << "Enter the season: " << endl;
    cin >> season;
    if (bgn <= 100)
    {
        cout << "Somewhere in Bulgaria" << endl;
        if (season == "summer")
        {
            a = (bgn * 30.00) / 100.00;
            cout << "camp"
                 << " - " << a ;
        }
        if (season == "winter")
        {
            a = (bgn * 70.00) / 100.00;
            cout << "hotel"
                 << " - " << a;
        }
    }
    else if (bgn <= 1000)
    {
        cout << "Somewhere in Balkans" << endl;
        if (season == "summer")
        {
            a = bgn * 40.00 / 100.00;
            cout << "camp"
                 << " - " << a;
        }
        if (season == "winter")
        {
            a = bgn * 80.00 / 100.00;
            cout << "hotel"
                 << " - " << a;
        }
    }

    else if (bgn > 1000)
    {
        cout << "Somewhere in Europe" << endl;
        if (season == "summer" || season == "winter")
        {
            a = bgn * 90.00 / 100.00;
            cout << "hotel"
                 << " - " << a;
        }
    }
}