#include<iostream>
using namespace std;
main(){
    int k;
    float m;
    cout<<"Enter kilometer per hour: "<<endl;
    cin>>k;
    m=k*0.62137;
    cout<<"Miles per hour: "<<m;


}