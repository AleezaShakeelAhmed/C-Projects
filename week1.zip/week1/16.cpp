#include<iostream>
using namespace std;
main(){
    int a,b,c,total,total1,total2;
    cout<<"Enter first: "<<endl;
    cin>>a;
    cout<<"Enter second: "<<endl;
    cin>>b;
    cout<<"Enter third: "<<endl;
    cin>>c;
    total=a+b+c;
    total1=total/60;
    total2=total%60;
    if(total2<10){
        cout<<total1<<":0"<<total2;
    }
    else{
    cout<<total1<<":"<<total2;
    }
}