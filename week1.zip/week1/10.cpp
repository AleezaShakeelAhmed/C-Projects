#include<iostream>
using namespace std;
main(){
    int a,b,c,d;
    cout<<"Enter first angle: "<<endl;
    cin>>a;
    cout<<"Enter second angle: "<<endl;
    cin>>b;
    d=a+b;
    c=180-d;
    cout<<"Third angle of a triangle is: "<<c;
    

}