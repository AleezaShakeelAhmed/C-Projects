#include<iostream>
using namespace std;
main(){
    int n,n1,n2,n3;
    cout<<"Enter any number: "<<endl;
    cin>>n;
    if(n==0){
        cout<<"zero";
    }
    else if(n==1){
        cout<<"one";
    }
     else if(n==2){
        cout<<"two";
    }
     else if(n==3){
        cout<<"three";
    }
     else if(n==4){
        cout<<"four";
    }
     else if(n==5){
        cout<<"five";
    }
     else if(n==6){
        cout<<"six";
    }
     else if(n==7){
        cout<<"seven";
    }
     else if(n==8){
        cout<<"eight";
    }
     else if(n==9){
        cout<<"nine";
    }
    else if(n==10){
        cout<<"ten";
    }

     else if(n==11){
        cout<<"eleven";
    }
     else if(n==12){
        cout<<"twelve";
    }
     else if(n==13){
        cout<<"thirteen";
    }
     else if(n==14){
        cout<<"fourteen";
    }
     else if(n==15){
        cout<<"fifteen";
    }
     else if(n==16){
        cout<<"sixteen";
    }
     else if(n==17){
        cout<<"seventeen";
    }
     else if(n==18){
        cout<<"eighteen";
    }
     else if(n==19){
        cout<<"nineteen";
    }
     else if(n==20){
        cout<<"twenty";
    }
      else if(n==30){
        cout<<"thirty";
    }
      else if(n==40){
        cout<<"fourty";
    }
      else if(n==50){
        cout<<"fifty";
    }
      else if(n==60){
        cout<<"sixty";
    }
      else if(n==70){
        cout<<"seventy";
    }
      else if(n==80){
        cout<<"eighty";
    }
      else if(n==90){
        cout<<"ninty";
    }
      else if(n==100){
        cout<<"hundred";
    }
    else {
    n1=n%10;
    n2=n/10;
    n3=n2%10;
    if(n3==2){
        if(n1==1)
        cout<<"twenty"<<" "<<"one";
        if(n1==2)
        cout<<"twenty"<<" "<<"two";
        if(n1==3)
        cout<<"twenty"<<" "<<"three";
        if(n1==4)
        cout<<"twenty"<<" "<<"four";
        if(n1==5)
        cout<<"twenty"<<" "<<"five";
        if(n1==6)
        cout<<"twenty"<<" "<<"six";
        if(n1==7)
        cout<<"twenty"<<" "<<"seven";
        if(n1==8)
        cout<<"twenty"<<" "<<"eight";
        if(n1==9)
        cout<<"twenty"<<" "<<"nine";
    }
   else if(n3==3){
        if(n1==1)
        cout<<"thirty"<<" "<<"one";
        if(n1==2)
        cout<<"thirty"<<" "<<"two";
        if(n1==3)
        cout<<"thirty"<<" "<<"three";
        if(n1==4)
        cout<<"thirty"<<" "<<"four";
        if(n1==5)
        cout<<"thirty"<<" "<<"five";
        if(n1==6)
        cout<<"thirty"<<" "<<"six";
        if(n1==7)
        cout<<"thirty"<<" "<<"seven";
        if(n1==8)
        cout<<"thirty"<<" "<<"eight";
        if(n1==9)
        cout<<"thirty"<<" "<<"nine";
    }
   else if(n3==4){
        if(n1==1)
        cout<<"fourty"<<" "<<"one";
        if(n1==2)
        cout<<"fourty"<<" "<<"two";
        if(n1==3)
        cout<<"fourty"<<" "<<"three";
        if(n1==4)
        cout<<"foury"<<" "<<"four";
        if(n1==5)
        cout<<"fourty"<<" "<<"five";
        if(n1==6)
        cout<<"fourty"<<" "<<"six";
        if(n1==7)
        cout<<"fourty"<<" "<<"seven";
        if(n1==8)
        cout<<"fourty"<<" "<<"eight";
        if(n1==9)
        cout<<"fourty"<<" "<<"nine";
    }
   else if(n3==5){
        if(n1==1)
        cout<<"fifty"<<" "<<"one";
        if(n1==2)
        cout<<"fifty"<<" "<<"two";
        if(n1==3)
        cout<<"fifty"<<" "<<"three";
        if(n1==4)
        cout<<"fifty"<<" "<<"four";
        if(n1==5)
        cout<<"fifty"<<" "<<"five";
        if(n1==6)
        cout<<"fifty"<<" "<<"six";
        if(n1==7)
        cout<<"fifty"<<" "<<"seven";
        if(n1==8)
        cout<<"fifty"<<" "<<"eight";
        if(n1==9)
        cout<<"fifty"<<" "<<"nine";
    }
    else if(n3==6){
        if(n1==1)
        cout<<"sixty"<<" "<<"one";
        if(n1==2)
        cout<<"sixty"<<" "<<"two";
        if(n1==3)
        cout<<"sixty"<<" "<<"three";
        if(n1==4)
        cout<<"sixty"<<" "<<"four";
        if(n1==5)
        cout<<"sixty"<<" "<<"five";
        if(n1==6)
        cout<<"sixty"<<" "<<"six";
        if(n1==7)
        cout<<"sixty"<<" "<<"seven";
        if(n1==8)
        cout<<"sixty"<<" "<<"eight";
        if(n1==9)
        cout<<"sixty"<<" "<<"nine";
    }
   else if(n3==7){
        if(n1==1)
        cout<<"seventy"<<" "<<"one";
        if(n1==2)
        cout<<"seventy"<<" "<<"two";
        if(n1==3)
        cout<<"seventy"<<" "<<"three";
        if(n1==4)
        cout<<"seventy"<<" "<<"four";
        if(n1==5)
        cout<<"seventy"<<" "<<"five";
        if(n1==6)
        cout<<"seventy"<<" "<<"six";
        if(n1==7)
        cout<<"seventy"<<" "<<"seven";
        if(n1==8)
        cout<<"seventy"<<" "<<"eight";
        if(n1==9)
        cout<<"seventy"<<" "<<"nine";
    }
   else if(n3==8){
        if(n1==1)
        cout<<"eighty"<<" "<<"one";
        if(n1==2)
        cout<<"eighty"<<" "<<"two";
        if(n1==3)
        cout<<"eighty"<<" "<<"three";
        if(n1==4)
        cout<<"eighty"<<" "<<"four";
        if(n1==5)
        cout<<"eighty"<<" "<<"five";
        if(n1==6)
        cout<<"eighty"<<" "<<"six";
        if(n1==7)
        cout<<"eighty"<<" "<<"seven";
        if(n1==8)
        cout<<"eighty"<<" "<<"eight";
        if(n1==9)
        cout<<"eighty"<<" "<<"nine";
    }
   else if(n3==9){
        if(n1==1)
        cout<<"ninety"<<" "<<"one";
        if(n1==2)
        cout<<"ninety"<<" "<<"two";
        if(n1==3)
        cout<<"ninety"<<" "<<"three";
        if(n1==4)
        cout<<"ninety"<<" "<<"four";
        if(n1==5)
        cout<<"ninety"<<" "<<"five";
        if(n1==6)
        cout<<"ninety"<<" "<<"six";
        if(n1==7)
        cout<<"ninety"<<" "<<"seven";
        if(n1==8)
        cout<<"ninety"<<" "<<"eight";
        if(n1==9)
        cout<<"ninety"<<" "<<"nine";
    }
    
    }
}