#include <iostream>
using namespace std;
main()
{
    int n1, n2;
    int n;
    char op;
    cout << "Enter first number: " << endl;
    cin >> n1;
    cout << "Enter second number: " << endl;
    cin >> n2;
    cout << "Enter the operator: " << endl;
    cin >> op;
    if (op == '+')
    {
        n = n1 + n2;
        if (n % 2 == 0)
        {
            cout << n1 << op << n2 << "=" << n << "-"
                 << "even";
        }
        else
        {
            cout << n1 << op << n2 << "=" << n << "-"
                 << "odd";
        }
    }
    else if (op == '-')
    {
        n = n1 - n2;
        if (n % 2 == 0)
        {
            cout << n1 << op << n2 << "=" << n << "-"
                 << "even";
        }
        else
        {
            cout << n1 << op << n2 << "=" << n << "-"
                 << "odd";
        }
    }
    else if (op == '*')
    {
        n = n1 * n2;
        if (n % 2 == 0)
        {
            cout << n1 << op << n2 << "=" << n << "-"
                 << "even";
        }
        else
        {
            cout << n1 << op << n2 << "=" << n << "-"
                 << "odd";
        }
    }
    else if (op == '/')
    {
        if (n2 == 0)
        {
            cout << "Cannot divide"
                 << " " << n1 <<" "<< "by zero";
        }
        else
        {
            float m = n1*1.00 / n2*1.00;
            cout << n1 << op << n2 << "=" << m;
        }
    }
    else if (op == '%')
    {
        if (n2 == 0)
        {
            cout << "Cannot divide"
                 << " " << n1 <<" "<< "by zero";
        }
        else
        {
            n = n1 % n2;
            cout << n1 << op << n2 << "=" << n;
        }
    }
}