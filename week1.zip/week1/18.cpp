#include<iostream>
using namespace std;
main()
{
    int full,per1,per2;
    float pipesum;
    cout<<"enter volume : ";
    int volume;
    cin>>volume;
    cout<<"enter pipe 1 : ";
    float p1;
    cin>>p1;
    cout<<"enter pipe 2 : ";
    float p2;
    cin>>p2;
    cout<<"enter hours  : ";
    float time;
    cin>>time;
    float p11,p22;
     p11=p1*time;
     p22=p2*time;
      pipesum=p11+p22;
     full=pipesum/volume*100;
    per1=p11/pipesum*100;
    per2=p22/pipesum*100;
    if(volume>full){

    cout<<"The pool is"<<" "<<full<<"% "<<"full."<<"Pipe 1:"<<per1<<"%."<<"Pipe 2:"<<per2<<"%";
    }
    else {
        float over=pipesum-volume;
        float hour1=pipesum/time;
        float overhours=over/hour1;
        cout<<"For "<<overhours<<" "<<"hours the pool overflows with "<<over<<" "<<"over";
    }
}