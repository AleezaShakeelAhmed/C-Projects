#include <iostream>
using namespace std;
main()
{
    int size, liters, workers;
    float one, total_grapes, used, wine, left;
    cout << "Enter the size of vineyard: " << endl;
    cin >> size;
    cout << "Grapes one meter square: " << endl;
    cin >> one;
    cout << "Needed liters of wine: " << endl;
    cin >> liters;
    cout << "Enter number of workers: " << endl;
    cin >> workers;
    total_grapes = size * one;
    used = total_grapes * 40 / 100;
    wine = used / 2.5;
    if (liters > wine)
    {
        int left = liters - wine;
        cout << "It will be tough winter!more"
             << " " << left << " "
             << "liters wine needed." << endl;
    }
    else if (liters < wine)
    {
        cout << "Good harvest this year! Total wine:" << wine << "liters." << endl;
        left = wine - liters;
        cout << left << " "
             << "liters left" << endl;
        left = left / workers;
        cout << left << " "
             << "liters per person" << endl;
    }
}
