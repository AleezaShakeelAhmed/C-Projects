#include<iostream>
using namespace std;
main(){
    float grade;
    cout<<"Enter your grades: "<<endl;
    cin>>grade;
    if(grade>=5.50){
        cout<<"Excellent!";
    }
}