#include<iostream>
using namespace std;
main(){
    int hours,minutes,total;
    cout<<"Enter total hours: "<<endl;
    cin>>hours;
    cout<<"Enter total minutes: "<<endl;
    cin>>minutes;
    total=hours*60+minutes;
    cout<<"Total minutes are: "<<total;

}