#include<iostream>
using namespace std;
main(){
    int a,b,c;
    cout<<"Enter first side of triangle: "<<endl;
    cin>>a;
    cout<<"Enter second side of triangle: "<<endl;
    cin>>b;
    cout<<"Enter third side of triangle: "<<endl;
    cin>>c;
    
    if(a==b&&b==c){
        cout<<"Equilateral triangle.";
    }
    else if(a!=b&&b!=c&&a!=c){
        cout<<"Scalene triangle.";
    }
    else if(a==b||b==c||a==c){
        cout<<"Isoceles triangle.";
    }
}