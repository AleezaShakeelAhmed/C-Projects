#include <iostream>
using namespace std;
main()
{

    int h1, h2, m1, m2, a, b, c, d, e;
    a = m2 - m1;
    cout << "Enter exam starting time in hours: " << endl;
    cin >> h1;
    cout << "Enter exam starting time in minutes: " << endl;
    cin >> m1;
    cout << "Enter the hour of arrival: " << endl;
    cin >> h2;
    cout << "Enter the minutes of arrival: " << endl;
    cin >> m2;
    a = h1 * 60 + m1;
    b = h2 * 60 + m2;
    c = a - b;
    if (c == 0 )
    {
        cout << "On time";
    }
    
    
    else if (c*(-1) > 0)
    {
        cout << "Late" << endl;
        if (c*(-1) < 60)
        {
            cout << c*(-1) <<" "<< "minutes after the start";
        }
        else if (c*(-1) >= 60)
        {
            d = c*(-1) / 60;
            e = c*(-1) % 60;
            cout << d <<":"<< e << "hours after the start";
        }
    }
    else if(c<=30){
        cout<<"On time"<<endl;
        cout<<c<<" "<<"minutes before the start";
    }
    else if (c > 30)
    {
        cout << "Early" << endl;
        if (c > 30 && c < 60)
        {
            cout << c << " "
                 << "minutes before the start";
        }
        else if(c==60){
            cout<<"1:00 before the start";
        }
        
       
        else if (c >= 60)
        {
            d = c / 60;
            e = c % 60;
            cout << d << ":" << e <<" "<< "hours before the start";
        }
    }
}