#include<iostream>
using namespace std;
main(){
    int n1,n2;
    float add,sub,mul,div,mod;
    cout<<"Enter first number: "<<endl;
    cin>>n1;
    cout<<"Enter second number: "<<endl;
    cin>>n2;
    add=n1+n2;
    sub=n1-n2;
    mul=n1*n2;
    div=n1/n2;
    mod=n1%n2;
    cout<<add<<'\n'<<sub<<'\n'<<mul<<'\n'<<div<<'\n'<<mod;
    

}