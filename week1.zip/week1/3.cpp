#include<iostream>
using namespace std;
main(){
    int length,width;
    float perimeter;
    cout<<"Enter length: "<<endl;
    cin>>length;
    cout<<"Enter width: "<<endl;
    cin>>width;
    perimeter=2*(length+width);
    cout<<"perimeter of a rectangle: "<<perimeter;
    
}