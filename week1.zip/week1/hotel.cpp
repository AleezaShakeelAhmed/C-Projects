#include <iostream>
using namespace std;
main()
{
    float one_room, booked, days, sales_text, paid, disc, each, bill;
    cout << "Enter the cost of renting one room: " << endl;
    cin >> one_room;
    cout << "Enter the number of rooms which are booked: " << endl;
    cin >> booked;
    cout << "Enter the number of days the rooms are booked: " << endl;
    cin >> days;
    cout << "Enter the sales tax in percentage: " << endl;
    cin >> sales_text;
    if (booked < 10)
    {
        paid = booked * 100.00;
    }
    if (days < 3)
    {

        if (booked >= 10 || booked < 20)
        {

            disc = 100.00 * 10 / 100;
            cout << "The discount on each room as a percent: " << disc << "%" << endl;

            paid = 100.00 - disc;
            each = 10 / disc;
        }
        else if (booked >= 20 || booked < 30)
        {
            disc = 100.00 * 20 / 100;
            cout << "The discount on each room as a percent: " << disc << "%" << endl;

            paid = 100.00 - disc;
            each = 20 / disc;
        }
        else if (booked >= 30 || booked < 40)
        {
            disc = 100.00 * 30 / 100;
            cout << "The discount on each room as a percent: " << disc << "%" << endl;

            paid = 100.00 - disc;
            each = 30 / disc;
        }
    }
    else if (days >= 3)
    {
        if (booked >= 10 || booked < 20)
        {

            disc = 100.00 * 15 / 100;
            cout << "The discount on each room as a percent: " << disc << "%" << endl;

            paid = 100.00 - disc;
            each = 15 / disc;
        }
        else if (booked >= 20 || booked < 30)
        {
            disc = 100.00 * 25 / 1000;
            cout << "The discount on each room as a percent: " << disc << "%" << endl;

            paid = 100.00 - disc;
            each = 25 / disc;
        }
        else if (booked >= 30 || booked < 40)
        {
            disc = 100.00 * 35 / 100;
            cout << "The discount on each room as a percent: " << disc << "%" << endl;

            paid = 100.00 - disc;
            each = 35 / disc;
        }
    }
    cout << "Cost of 1 room: " << one_room << endl;

    cout << "The number of rooms booked are: " << booked << endl;
    cout << "The number of days the rooms are booked: " << days << endl;
    cout << "The total cost of the rooms: " << paid << endl;

    cout << "Sales text is: " << sales_text << endl;
    bill = paid + sales_text;

    cout << "The total bill of a customer is: " << bill;
}
