#include<iostream>
using namespace std;
main(){
    float n1,n2,n3,sum;
    cout<<"Enter first number: "<<endl;
    cin>>n1;
    cout<<"Enter second number: "<<endl;
    cin>>n2;
    cout<<"Enter third number: "<<endl;
    cin>>n3;
    sum=n1+n2+n3;
    cout<<"Sum of numbers is: "<<sum;
}
