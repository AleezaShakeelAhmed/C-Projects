#include<iostream>
using namespace std;
main(){
    string fn,sn,dob;
    cout<<"Enter first name: "<<endl;
    cin>>fn;
     cout<<"Enter second name: "<<endl;
    cin>>sn;
     cout<<"Enter year of birth: "<<endl;
    cin>>dob;
    cout<<fn<<'\n'<<sn<<'\n'<<dob;

}