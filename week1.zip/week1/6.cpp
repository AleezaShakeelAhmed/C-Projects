#include<iostream>
using namespace std;
main(){
    int m,hours,minutes;
    cout<<"Enter minutes: "<<endl;
    cin>>m;
    hours=m/60;
    minutes=m%60;
    cout<<hours<<"hours"<<":"<<minutes<<"minutes";

}