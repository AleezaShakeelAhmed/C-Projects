#include<iostream>
using namespace std;
main(){
    float np,en,first,second,third,netprice,per,firstly,over,ov,t;
    cout<<"Enter the net price of each copy of the novel: "<<endl;
    cin>>np;
    cout<<"Enter the estimated number of copies that will be sold: "<<endl;
    cin>>en;
    first=5000+20000;
    cout<<"first"<<first<<endl;
    netprice=np*en;
    per=netprice*12.5/100;
     second=per;
     cout<<"second"<<second<<endl;
     if(en<=4000){
            third = np * 10.0 / 100.0 * en;
     cout<<"third"<<third<<endl;

         
     }
     else{
     third=((np*(4000*10/100)+np*((en-4000)*14/100)));
     cout<<"third"<<third<<endl;
     }

     

     if(first>second&&first>third){
         cout<<"The author should choose first option.";
     }
     else if(second>first&&second>third){
         cout<<"The author should choose second option.";

     }
     else if(third>first&&third>second){
         cout<<"The author should choose third option.";

     }
     else if(first==second&&second==third){
         cout<<"The author can choose any of the option.";
     }
     

     
}