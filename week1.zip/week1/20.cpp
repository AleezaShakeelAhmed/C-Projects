#include <iostream>
using namespace std;
main()
{
  int h1, h2, m1, m2,a,b,c;
    a = m2 - m1;
  cout << "Enter exam starting time in hours: " << endl;
  cin >> h1;
  cout << "Enter exam starting time in minutes: " << endl;
  cin >> m1;
  cout << "Enter the hour of arrival: " << endl;
  cin >> h2;
  cout << "Enter the minutes of arrival: " << endl;
  cin >> m2;
  a=h1*60+m1;
  b=h2*60+m2;
  c=a-b;
  if(c>30){
    cout<<"Too early"<<c;
  }
 else if(c<30&&c>=0){
    cout<<"On time"<<c;

  }
  else if(c<0){
    c=c*-1;
    cout<<"late"<<c;
  }

 
}
