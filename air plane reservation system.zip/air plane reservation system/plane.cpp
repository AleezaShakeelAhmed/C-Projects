#include <iostream>
#include <fstream>
#include <conio.h>
using namespace std;
fstream file;
// functions prototype
void store();
void load();
void a();
void header();
void show();
char seats[13][6] = {{'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'},
                     {'*', '*', '*', '*', '*', '*'}};
// main function
main()
{

    string category;
    int row;
    int column;
    int n;

    while (true)
    {
        header();

        show();
        cout << "\n\n\n"
             << "If you want to exit the system please enter 10 and if you want to use the system please enter 1:";
        cin >> n;

        if (n == 1)
        {

            system("cls");
            header();
            cout << "WE HAVE THE FOLLOWING CATEGORIES" << endl;

            a();
            cout << "                                " << endl;
            cout << "Please enter the  class: ";

            getline(cin >> ws, category);

            if (category == "first class")
            {

                for (int i = 0; i < 2; i++)
                {
                    for (int j = 0; j < 6; j++)
                    {
                        cout << seats[i][j] << "        ";
                    }
                    cout << endl;
                }
                cout << "Enter row number: " << endl;
                cin >> row;
                cout << "Enter column number: " << endl;
                cin >> column;

                if (seats[row - 1][column - 1] == 'X')
                {
                    cout << "This seat is reserved............." << endl;
                }
                if (seats[row - 1][column - 1] == '*')
                {
                    seats[row - 1][column - 1] = 'X';
                }

                store();
                load();
                getch();
            }
            else if (category == "business class")
            {
                for (int i = 2; i < 6; i++)
                {
                    for (int j = 0; j < 6; j++)
                    {
                        cout << seats[i][j] << "         ";
                    }
                    cout << endl;
                }
                cout << "enter row number: " << endl;
                cin >> row;
                cout << "enter column number: " << endl;
                cin >> column;

                if (seats[row - 1][column - 1] == 'X')
                {
                    cout << "This seat is reserved............." << endl;
                }
                if (seats[row - 1][column - 1] == '*')
                {
                    seats[row - 1][column - 1] = 'X';
                }
                store();
                load();
                getch();
            }

            else if (category == "economy class")
            {
                for (int i = 6; i < 13; i++)
                {
                    for (int j = 0; j < 6; j++)
                    {
                        cout << seats[i][j] << "         ";
                    }
                    cout << endl;
                }

                cout << "enter row number: " << endl;
                cin >> row;
                cout << "enter column number: " << endl;
                cin >> column;

                if (seats[row - 1][column - 1] == 'X')
                {
                    cout << "This seat is reserved............." << endl;
                }
                if (seats[row - 1][column - 1] == '*')
                {
                    seats[row - 1][column - 1] = 'X';
                }

                store();
                load();
                getch();
            }
        }
        else if (n == 10)
        {
            break;
        }
    }
}
// function for the header
void header()
{
    system("cls");
    cout << "                             *****************************************************" << endl;
    cout << "                             _____________________________________________________" << endl;
    cout << "                                       FLIGHT MANAGEMENT SYSTEM" << endl;
    cout << "                             _____________________________________________________" << endl;
    cout << "                             *****************************************************" << endl;
    cout << "\n"
         << "\n"
         << endl;
}
void a()
{

    cout << "First class" << endl;
    cout << "Business Class" << endl;
    cout << "Economy Class" << endl;
    cout << "PLEASE KEEP IN NOTICE WHILE ENTERING THE ROW AND COLUMN" << endl;
    cout << "Row first and second is first class. Row 3 to 6 are business class and row 7 to 13 are economy class. " << endl;
}
// function to show the airplane system
void show()
{
    cout << "               "
         << "A"
         << "           "
         << "B"
         << "           "
         << "C"
         << "           "
         << "D"
         << "           "
         << "E"
         << "           "
         << "F" << endl;
    cout << "row1"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row2"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row3"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row4"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row5"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row6"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row7"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row8"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row9"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row10"
         << "          "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row11"
         << "          "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row12"
         << "          "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
    cout << "row13"
         << "          "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*"
         << "           "
         << "*" << endl;
}
// function for store data
void store()
{
    file.open("plane.txt", ios::out);
    for (int s = 0; s < 13; s++)
    {
        for (int t = 0; t < 6; t++)
        {
            file << seats[s][t] << " ";
        }
        file << endl;
    }
    file.close();
}
// function for load data
void load()
{
    string record;
    file.open("plane.txt", ios::in);
    for (int i = 0; i < 13; i++)
    {
        for (int j = 0; j < 6; j++)
        {
            file >> seats[i][j];
        }
    }
    file.close();
    getch();
    system("cls");
    header();
    cout << "                                          " << endl;
    cout << "                                          " << endl;

    cout << "                                          " << endl;

    for (int x = 0; x < 13; x++)
    {
        for (int y = 0; y < 6; y++)
        {
            cout << seats[x][y];
        }
        cout << endl;
    }
}
