#include<iostream>
#include<conio.h>
using namespace std;
int miss(int a[9]);
int main()
{
    int a[9];
  for(int i=0;i<9;i++){
      cout<<"enter number between 1 and 10: "<<endl;
      cin>>a[i];
  }  
  cout<<miss(a);
}
int miss(int a[9]){
     for(int i=0;i<9;i++){
        for(int j=i+1;j<9;j++){
            if(a[i]>a[j]){
           int temp=a[i];
           a[i]=a[j];
           a[j]=temp;
            }
         }
    }
    int b=1;
   for(int i=0;i<10;i++){
       if(a[i]==b){
             b++;
           continue;
       }
       else{
           return b;
         
       }
         
        
   }

}


