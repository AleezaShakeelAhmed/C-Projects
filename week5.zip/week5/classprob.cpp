#include <iostream>
#include <conio.h>
using namespace std;
void posnegsort(int a[], int n);
int main()
{
    int a[10];
    int n;
    cout << "Enter the size of the array: " << endl;
    cin >> n;
    posnegsort(a, n);
}

void posnegsort(int a[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Enter the value: " << endl;
        cin >> a[i];
    }
    
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (a[j] > 0)
            {
                if (a[i] > a[j])
                {
                    int asc = a[i];
                    a[i] = a[j];
                    a[j] = asc;
                }
            }
        }
    }

    for (int i = 0; i < n; i++)
    {
        cout << a[i] << " ";
    }
}
