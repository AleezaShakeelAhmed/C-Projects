#include<iostream>
#include<conio.h>
using namespace std;
bool sequence(int a[],int n);
int main()
{
    int a[10];
    int n;
    cout<<"Enter the size of array: "<<endl;
    cin>>n;
    for(int i=0;i<n;i++){
        cout<<"Enter value: "<<endl;
        cin>>a[i];
    }
    cout<<sequence(a,n);
}
bool sequence(int a[],int n){
    int count=0;
    for(int i=0;i<n;i++)
    {
       if(a[i]<a[i+i]){
           continue;
       }
       if(a[i]>a[i+1]){
           count++;
       }
       if(a[i]==a[i+2]){
           count++;
       }
       
    }
     if(count<=1){
         return true;
     }
     else{
         return false;
     }
}

