#include<iostream>
#include<conio.h>
using namespace std;
int countboomeranges(int a[],int n);
int main()
{
    int a[10];
  int n;
 cout<<"Enter the size of the array: "<<endl;
 cin>>n; 
 cout<<countboomeranges(a,n);  
}
int countboomeranges(int a[],int n){
    int count=0;
     for(int i=0;i<n;i++){
        cout<<"Enter the value: "<<endl;
        cin>>a[i];
    }
      for(int i=0;i<n-2;i++){
          if(a[i]==a[i+1]&&a[i]==a[i+2]){
            count--;
        } 
        if(a[i]==a[i+2]){
            count++;
        }
       
        
    }
    return count;
}
