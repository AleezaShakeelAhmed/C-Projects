#include <iostream>
#include <conio.h>
using namespace std;
bool ispositivedominant(int a[], int n);
int main()
{
    int a[10];
    int n;
    cout << "Enter the size of the array: " << endl;
    cin >> n;
    bool result = ispositivedominant(a, n);
    if (result == 1)
    {
        cout << "true";
    }
    if (result == 0)
    {
        cout << "false";
    }
}
bool ispositivedominant(int a[], int n)
{
    int count = 0;
    int check = 0;
    int c = 0;

    int const size = 10;
    int newa[size];
    int z=0;
    for (int i = 0; i < n; i++)
    {
        cout << "Enter the value: " << endl;
        cin >> a[i];
        if (a[i] > 0)
        {

            count++;
            newa[z] = a[i];
            z++;
        }
        if (a[i] < 0)
        {
            check++;
        }
    }
    if (count > check)
    {
        for (int i = 0; i < z; i++)
        {
            for (int j = i + 1; j < z; j++)
            {
                if (newa[i] == newa[j])
                {
                    return false;
                }
            }
        }
    }
    else
    {
        return false;
    }

    return true;
}