#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int b=0;
    int d=0;
     int a[10];
     int c[9];
  for(int i=0;i<10;i++){
      cout<<"enter first ten numbers: "<<endl;
      cin>>a[i];
      b=b+a[i];
  }  
  for(int i=0;i<9;i++){
      cout<<"enter numbers between 1 and ten of your own choice: "<<endl;
      cin>>c[i];
    d=d+c[i];
  }
  int f=b-d;
  cout<<f;
}