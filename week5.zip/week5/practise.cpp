#include<iostream>
#include<conio.h>
using namespace std;

void swap(int a[5]);

int main()
{
 
 int a[5]={7,5,3,2,8};
    swap(a);
}
void swap(int a[5]){
    
    for(int i=0;i<5;i++){
        for(int j=i+1;j<5;j++){
            if(a[i]<a[j]){
           int temp=a[i];
           a[i]=a[j];
           a[j]=temp;
            }
        }
      
    }
    for(int i=0;i<5;i++){
        cout<<a[i]<<" ";
    }
}