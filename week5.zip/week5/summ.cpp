#include <iostream>
#include <conio.h>
using namespace std;
int summissingnumbers(int a[], int n);
int main()
{
    int a[10];
    int n;
    cout << "Enter the size of the array: " << endl;
    cin >> n;
     cout<<summissingnumbers(a, n);
}
int summissingnumbers(int a[], int n)
{

    int result = 0;
    for (int i = 0; i < n; i++)
    {
        cout << "Enter the value: " << endl;
        cin >> a[i];
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (a[i] > a[j])
            {
                int asc = a[i];
                a[i] = a[j];
                a[j] = asc;
            }
        }
    }

    for (int i = 0; i < n-1; i++)
    {

        int diff = a[i + 1] - a[i];
        if (diff >= 2)
        {
            int number = a[i];
            for (int j = 1; j <= diff - 1; j++)
            {
                number++;
                result = result + (number);
            }
        }
    }

    return result;
}
