#include<iostream>
#include<conio.h>
using namespace std;
string interview(int a[],int n);
int main()
{
  
  int a[8];
  int n;
 cout<<"Enter the total time limit of the interview: "<<endl;
 cin>>n;
cout<<interview(a,n);   
}
string interview(int a[],int n){
    int c;
    cout<<"Enter the number of questions: "<<endl;
    cin>>c;
     for(int i=0;i<c;i++){

        cout<<"Enter the value: "<<endl;
        cin>>a[i];
       
    }
     if(c<8){

            return "disqualified";
            
        }
         
    if(a[0]<=5&&a[1]<=5&&a[2]<=10&&a[3]<=10&&a[4]<=15&&a[5]<=15&&a[6]<=20&&a[7]<=20){
    if(n>120){
        return "disqualified";
    }
    }
    if(a[0]<=5&&a[1]<=5&&a[2]<=10&&a[3]<=10&&a[4]<=15&&a[5]<=15&&a[6]<=20&&a[7]<=20){
        if(n<=120){
            return "qualified";
        }
    }
    else{
        return "disqualified";
    }
  
}
