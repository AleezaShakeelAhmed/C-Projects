#include<iostream>
#include<conio.h>
using namespace std;
int small(int a[],int n,int k);

int main()
{   int a[10];
    int n,k;
    cout<<"Enter the size of array: "<<endl;
    cin>>n;
    for(int i=0;i<n;i++){
        cout<<"Enter value: "<<endl;
        cin>>a[i];
    }
    cout<<small(a,n,k);
    
    if(k<1){
        cout<<"no possible"<<endl;
    }
    
}
int small(int a[],int n,int k){


cout<<"Enter the number at which u want to see the value: "<<endl;
    cin>>k;
    return a[k-1];
    if(k>n){
        return -1;
    }

}

