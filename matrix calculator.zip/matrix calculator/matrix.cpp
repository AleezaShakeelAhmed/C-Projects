#include <iostream>
#include <conio.h>
using namespace std;
// function prototypes
void addition(int array1[][5], int array2[][5]);
void subtract(int array1[][5], int array2[][5]);
void multiplication(int array1[][5], int array2[][5]);
void scalarmultiplication(int array1[][5]);
void identity(int array1[][5]);
void transpose(int array1[][5]);
void diagonal(int array1[][5]);
void symmetric(int array1[][5]);

void header();

// main function
int main()
{
    while (true)
    {
        system("cls");
        string operation;
        int array1[5][5];
        int array2[5][5];

        header();
        cout << "Which operation you want to perform on the values: " << endl;
        cout << "If you want to exit the system please enter exit instead of any opreration..........";
        getline(cin >> ws, operation);
        if (operation == "scalar multiplication")
        {
            scalarmultiplication(array1);
        }
        else if (operation == "identity")
        {
            identity(array1);
        }

        else if (operation == "transpose")
        {
            transpose(array1);
        }
        else if (operation == "symmetric")
        {
            symmetric(array1);
        }
        else if (operation == "diagonal")
        {
            diagonal(array1);
        }

        else if (operation == "addition")
        {
            addition(array1, array2);
        }
        else if (operation == "subtraction")
        {
            subtract(array1, array2);
        }
        else if (operation == "multiplication")
        {
            multiplication(array1, array2);
        }

        else if (operation == "exit")
        {
            break;
        }
    }
}

// function for the addition.......
void addition(int array1[][5], int array2[][5])
{

    int rows, columns, result;
    cout << "Enter the number of rows of both matrices: ";
    cin >> rows;
    cout << "Enter the number of columns of both matrices: ";
    cin >> columns;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            cout << "Enter the values of the first matrix: ";
            cin >> array1[i][j];
        }
    }
    for (int x = 0; x < rows; x++)
    {
        for (int y = 0; y < columns; y++)
        {
            cout << "Enter the values of the second matrix: ";
            cin >> array2[x][y];
        }
    }
    for (int s = 0; s < rows; s++)
    {
        for (int t = 0; t < columns; t++)
        {
            result = array1[s][t] + array2[s][t];
            cout << result << "    ";
        }
        cout << endl;
    }

    getch();
}

// function for the subtraction.......
void subtract(int array1[][5], int array2[][5])
{
    int rows, columns, result;
    cout << "Enter the number of rows of both matrices: ";
    cin >> rows;
    cout << "Enter the number of columns of both matrices: ";
    cin >> columns;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            cout << "Enter the values of the first matrix: ";
            cin >> array1[i][j];
        }
    }
    for (int x = 0; x < rows; x++)
    {
        for (int y = 0; y < columns; y++)
        {
            cout << "Enter the values of the second matrix: ";
            cin >> array2[x][y];
        }
    }
    for (int s = 0; s < rows; s++)
    {
        for (int t = 0; t < columns; t++)
        {
            result = array1[s][t] - array2[s][t];
            cout << result << "    ";
        }
        cout << endl;
    }

    getch();
}

// // function for the multiplication.....
void multiplication(int array1[][5], int array2[][5])
{
    int a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p;
    int rows1, rows2, columns1, columns2;
    cout << "Enter the number of rows of the first matrix:";
    cin >> rows1;
    cout << "Enter the number of columns of the first matrix:";
    cin >> columns1;
    cout << "Enter the number of rows of the second matrix:";
    cin >> rows2;
    cout << "Enter the number of columns of the second matrix:";
    cin >> columns2;
    if (columns1 != rows2)
    {
        cout << "Invalid.........";
    }
    else if (columns1 == rows2)
    {
        for (int i = 0; i < rows1; i++)
        {
            for (int j = 0; j < columns1; j++)
            {
                cout << "Enter the values of the first matrix: ";
                cin >> array1[i][j];
            }
        }
        for (int x = 0; x < rows2; x++)
        {
            for (int y = 0; y < columns2; y++)
            {
                cout << "Enter the values of the second matrix: ";
                cin >> array2[x][y];
            }
        }
        if (rows1 == 2 && columns1 == 2 && rows2 == 2 && columns2 == 2)
        {

            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]);
            c = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]);
            d = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]);
            cout << a << "  " << b << endl;
            cout << c << "  " << d << endl;
            getch();
        }
        else if (rows1 == 3 && columns1 == 3 && rows2 == 3 && columns2 == 3)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]) + (array1[0][2] * array2[2][1]);
            c = (array1[0][0] * array2[0][2]) + (array1[0][1] * array2[1][2]) + (array1[0][2] * array2[2][2]);
            d = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]) + (array1[1][2] * array2[2][0]);
            e = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]) + (array1[1][2] * array2[2][1]);
            f = (array1[1][0] * array2[0][2]) + (array1[1][1] * array2[1][2]) + (array1[1][2] * array2[2][2]);
            g = (array1[2][0] * array2[0][0]) + (array1[2][1] * array2[1][0]) + (array1[2][2] * array2[2][0]);
            h = (array1[2][0] * array2[0][1]) + (array1[2][1] * array2[1][1]) + (array1[2][2] * array2[2][1]);
            i = (array1[2][0] * array2[0][2]) + (array1[2][1] * array2[1][2]) + (array1[2][2] * array2[2][2]);

            cout << a << "  " << b << "  " << c << endl;
            cout << d << "  " << e << "  " << f << endl;
            cout << g << "  " << h << "  " << i << endl;
            getch();
        }
        else if (rows1 == 4 && columns1 == 4 && rows2 == 4 && columns2 == 4)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]) + (array1[0][3] * array2[3][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]) + (array1[0][2] * array2[2][1]) + (array1[0][3] * array2[3][1]);
            c = (array1[0][0] * array2[0][2]) + (array1[0][1] * array2[1][2]) + (array1[0][2] * array2[2][2]) + (array1[0][3] * array2[3][2]);
            d = (array1[0][0] * array2[0][3]) + (array1[0][1] * array2[1][3]) + (array1[0][2] * array2[2][3]) + (array1[0][3] * array2[3][3]);
            e = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]) + (array1[1][2] * array2[2][0]) + (array1[1][3] * array2[3][0]);
            f = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]) + (array1[1][2] * array2[2][1]) + (array1[1][3] * array2[3][1]);
            g = (array1[1][0] * array2[0][2]) + (array1[1][1] * array2[1][2]) + (array1[1][2] * array2[2][2]) + (array1[1][3] * array2[3][2]);
            h = (array1[1][0] * array2[0][3]) + (array1[1][1] * array2[1][3]) + (array1[1][2] * array2[2][3]) + (array1[1][3] * array2[3][3]);
            i = (array1[2][0] * array2[0][0]) + (array1[2][1] * array2[1][0]) + (array1[2][2] * array2[2][0]) + (array1[2][3] * array2[3][0]);
            j = (array1[2][0] * array2[0][1]) + (array1[2][1] * array2[1][1]) + (array1[2][2] * array2[2][1]) + (array1[2][3] * array2[3][1]);
            k = (array1[2][0] * array2[0][2]) + (array1[2][1] * array2[1][2]) + (array1[2][2] * array2[2][2]) + (array1[2][3] * array2[3][2]);
            l = (array1[2][0] * array2[0][3]) + (array1[2][1] * array2[1][3]) + (array1[2][2] * array2[2][3]) + (array1[2][3] * array2[3][3]);
            m = (array1[3][0] * array2[0][0]) + (array1[3][1] * array2[1][0]) + (array1[3][2] * array2[2][0]) + (array1[3][3] * array2[3][0]);
            n = (array1[3][0] * array2[0][1]) + (array1[3][1] * array2[1][1]) + (array1[3][2] * array2[2][1]) + (array1[3][3] * array2[3][1]);
            o = (array1[3][0] * array2[0][2]) + (array1[3][1] * array2[1][2]) + (array1[3][2] * array2[2][2]) + (array1[3][3] * array2[3][2]);
            p = (array1[3][0] * array2[0][3]) + (array1[3][1] * array2[1][3]) + (array1[3][2] * array2[2][3]) + (array1[3][3] * array2[3][3]);

            cout << a << "  " << b << "  " << c << "  " << d << endl;
            cout << e << "  " << f << "  " << g << "  " << h << endl;
            cout << i << "  " << j << "  " << k << "  " << l << endl;
            cout << m << "  " << n << "  " << o << "  " << p << endl;
            getch();
        }
        else if (rows1 == 2 && columns1 == 3 && rows2 == 3 && columns2 == 3)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]) + (array1[0][2] * array2[2][1]);
            c = (array1[0][0] * array2[0][2]) + (array1[0][1] * array2[1][2]) + (array1[0][2] * array2[2][2]);
            d = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]) + (array1[1][2] * array2[2][0]);
            e = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]) + (array1[1][2] * array2[2][1]);
            f = (array1[1][0] * array2[0][2]) + (array1[1][1] * array2[1][2]) + (array1[1][2] * array2[2][2]);

            cout << a << "  " << b << "  " << c << endl;
            cout << d << "  " << e << "  " << f << endl;
            getch();
        }
        else if (rows1 == 3 && columns1 == 2 && rows2 == 2 && columns2 == 2)
        {

            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]);
            c = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]);
            d = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]);
            e = (array1[2][0] * array2[0][0]) + (array1[2][1] * array2[1][0]);
            f = (array1[2][0] * array2[0][1]) + (array1[2][1] * array2[1][1]);
            cout << a << "  " << b << endl;
            cout << c << "  " << d << endl;
            cout << e << "  " << f << endl;
            getch();
        }
        else if (rows1 == 2 && columns1 == 4 && rows2 == 4 && columns2 == 2)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]) + (array1[0][3] * array2[3][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]) + (array1[0][2] * array2[2][1]) + (array1[0][3] * array2[3][1]);
            c = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]) + (array1[1][2] * array2[2][0]) + (array1[1][3] * array2[3][0]);
            d = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]) + (array1[1][2] * array2[2][1]) + (array1[1][3] * array2[3][1]);
            cout << a << "  " << b << endl;
            cout << c << "  " << d << endl;
            getch();
        }
        else if (rows1 == 4 && columns1 == 2 && rows2 == 2 && columns2 == 2)
        {

            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]);
            c = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]);
            d = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]);
            e = (array1[2][0] * array2[0][0]) + (array1[2][1] * array2[1][0]);
            f = (array1[2][0] * array2[0][1]) + (array1[2][1] * array2[1][1]);
            g = (array1[3][0] * array2[0][0]) + (array1[3][1] * array2[1][0]);
            h = (array1[3][0] * array2[0][1]) + (array1[3][1] * array2[1][1]);
            cout << a << "  " << b << endl;
            cout << c << "  " << d << endl;
            cout << e << "  " << f << endl;
            cout << g << "  " << h << endl;
            getch();
        }
        else if (rows1 == 3 && columns1 == 4 && rows2 == 4 && columns2 == 3)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]) + (array1[0][3] * array2[3][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]) + (array1[0][2] * array2[2][1]) + (array1[0][3] * array2[3][1]);
            c = (array1[0][0] * array2[0][2]) + (array1[0][1] * array2[1][2]) + (array1[0][2] * array2[2][2]) + (array1[0][3] * array2[3][2]);
            d = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]) + (array1[1][2] * array2[2][0]) + (array1[1][3] * array2[3][0]);
            e = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]) + (array1[1][2] * array2[2][1]) + (array1[1][3] * array2[3][1]);
            f = (array1[1][0] * array2[0][2]) + (array1[1][1] * array2[1][2]) + (array1[1][2] * array2[2][2]) + (array1[1][3] * array2[3][2]);
            g = (array1[2][0] * array2[0][0]) + (array1[2][1] * array2[1][0]) + (array1[2][2] * array2[2][0]) + (array1[2][3] * array2[3][0]);
            h = (array1[2][0] * array2[0][1]) + (array1[2][1] * array2[1][1]) + (array1[2][2] * array2[2][1]) + (array1[2][3] * array2[3][1]);
            i = (array1[2][0] * array2[0][2]) + (array1[2][1] * array2[1][2]) + (array1[2][2] * array2[2][2]) + (array1[2][3] * array2[3][2]);
            cout << a << "  " << b << "  " << c << endl;
            cout << d << "  " << e << "  " << f << endl;
            cout << g << "  " << h << "  " << i << endl;
            getch();
        }
        else if (rows1 == 4 && columns1 == 3 && rows2 == 3 && columns2 == 4)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]);
            b = (array1[0][0] * array2[0][1]) + (array1[0][1] * array2[1][1]) + (array1[0][2] * array2[2][1]);
            c = (array1[0][0] * array2[0][2]) + (array1[0][1] * array2[1][2]) + (array1[0][2] * array2[2][2]);
            d = (array1[0][0] * array2[0][3]) + (array1[0][1] * array2[1][3]) + (array1[0][2] * array2[2][3]);
            e = (array1[1][0] * array2[0][0]) + (array1[1][1] * array2[1][0]) + (array1[1][2] * array2[2][0]);
            f = (array1[1][0] * array2[0][1]) + (array1[1][1] * array2[1][1]) + (array1[1][2] * array2[2][1]);
            g = (array1[1][0] * array2[0][2]) + (array1[1][1] * array2[1][2]) + (array1[1][2] * array2[2][2]);
            h = (array1[1][0] * array2[0][3]) + (array1[1][1] * array2[1][3]) + (array1[1][2] * array2[2][3]);
            i = (array1[2][0] * array2[0][0]) + (array1[2][1] * array2[1][0]) + (array1[2][2] * array2[2][0]);
            j = (array1[2][0] * array2[0][1]) + (array1[2][1] * array2[1][1]) + (array1[2][2] * array2[2][1]);
            k = (array1[2][0] * array2[0][2]) + (array1[2][1] * array2[1][2]) + (array1[2][2] * array2[2][2]);
            l = (array1[2][0] * array2[0][3]) + (array1[2][1] * array2[1][3]) + (array1[2][2] * array2[2][3]);
            m = (array1[3][0] * array2[0][0]) + (array1[3][1] * array2[1][0]) + (array1[3][2] * array2[2][0]);
            n = (array1[3][0] * array2[0][1]) + (array1[3][1] * array2[1][1]) + (array1[3][2] * array2[2][1]);
            o = (array1[3][0] * array2[0][2]) + (array1[3][1] * array2[1][2]) + (array1[3][2] * array2[2][2]);
            p = (array1[3][0] * array2[0][3]) + (array1[3][1] * array2[1][3]) + (array1[3][2] * array2[2][3]);

            cout << a << "  " << b << "  " << c << "  " << d << endl;
            cout << e << "  " << f << "  " << g << "  " << h << endl;
            cout << i << "  " << j << "  " << k << "  " << l << endl;
            cout << m << "  " << n << "  " << o << "  " << p << endl;
            getch();
        }
        else if (rows1 == 1 && columns1 == 1 && rows2 == 1 && columns2 == 1)
        {
            a = array1[0][0] + array2[0][0];
            cout << a;
            getch();
        }
        else if (rows1 == 1 && columns1 == 2 && rows2 == 2 && columns2 == 1)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]);
            cout << a;
            getch();
        }
        else if (rows1 == 1 && columns1 == 3 && rows2 == 3 && columns2 == 1)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]);
            cout << a;
            getch();
        }
        else if (rows1 == 1 && columns1 == 4 && rows2 == 4 && columns2 == 1)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][1] * array2[1][0]) + (array1[0][2] * array2[2][0]) + (array1[0][3] * array2[3][0]);
            cout << a;
            getch();
        }
        else if (rows1 == 2 && columns1 == 1 && rows2 == 1 && columns2 == 2)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][0] * array2[0][1]);
            b = (array1[1][0] * array2[0][0]) + (array1[1][0] * array2[0][1]);
            cout << a << endl;
            cout << b << endl;
            getch();
        }
        else if (rows1 == 3 && columns1 == 1 && rows2 == 1 && columns2 == 3)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][0] * array2[0][1]) + (array1[0][0] * array2[0][2]);
            b = (array1[1][0] * array2[0][0]) + (array1[1][0] * array2[0][1]) + (array1[1][0] * array2[0][2]);
            c = (array1[2][0] * array2[0][0]) + (array1[2][0] * array2[0][1]) + (array1[2][0] * array2[0][2]);
            cout << a << endl;
            cout << b << endl;
            cout << c << endl;
            getch();
        }
        else if (rows1 == 4 && columns1 == 1 && rows2 == 1 && columns2 == 4)
        {
            a = (array1[0][0] * array2[0][0]) + (array1[0][0] * array2[0][1]) + (array1[0][0] * array2[0][2]) + (array1[0][0] * array2[0][3]);
            b = (array1[1][0] * array2[0][0]) + (array1[1][0] * array2[0][1]) + (array1[1][0] * array2[0][2]) + (array1[1][0] * array2[0][3]);
            c = (array1[2][0] * array2[0][0]) + (array1[2][0] * array2[0][1]) + (array1[2][0] * array2[0][2]) + (array1[2][0] * array2[0][3]);
            d = (array1[3][0] * array2[0][0]) + (array1[3][0] * array2[0][1]) + (array1[3][0] * array2[0][2]) + (array1[3][0] * array2[0][3]);

            cout << a << endl;
            cout << b << endl;
            cout << c << endl;
            cout << d << endl;
            getch();
        }
    }
}
// function for the scalar multiplication....
void scalarmultiplication(int array1[][5])
{
    int num, row, col, result = 0;
    cout << "Enter the number of rows of the matrix:";
    cin >> row;
    cout << "Enter the number of columns of the matrix: ";
    cin >> col;
    cout << "Enter the number with which you want to multiply:";
    cin >> num;

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << "Enter the values of the matrix: ";
            cin >> array1[i][j];
        }
    }
    for (int x = 0; x < row; x++)
    {
        for (int y = 0; y < col; y++)
        {
            result = num * array1[x][y];
            cout << result << "     ";
            result = 0;
        }
        cout << endl;
    }
    getch();
}
// function to check either the given matrix is identity or not..............
void identity(int array1[][5])
{
    int row, col;
    int check = 0;
    int count = 0;
    cout << "Enter the number of rows of the matrix:";
    cin >> row;
    cout << "Enter the number of columns of the matrix: ";
    cin >> col;
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << "Enter the values of the matrix: ";
            cin >> array1[i][j];
        }
    }
    for (int x = 0; x < row; x++)
    {
        for (int y = 0; y < col; y++)
        {
            if (x == y && array1[x][y] == 1)
            {
                check++;
            }
            if (x != y && array1[x][y] == 0)
            {
                count++;
            }
        }
    }
    if (check == row && count == ((row * col) - row))
    {

        cout << "It is an identity matrix............";
    }
    else
    {
        cout << "Not an identity matrix..........";
    }
    getch();
}

// // function to see the transpose of a matrix.....
void transpose(int array1[][5])
{
    int row, col;
    cout << "Enter the number of rows of the matrix:";
    cin >> row;
    cout << "Enter the number of columns of the matrix: ";
    cin >> col;
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << "Enter the values of the matrix: ";
            cin >> array1[i][j];
        }
    }
    for (int y = 0; y < col; y++)
    {
        for (int x = 0; x < row; x++)
        {

            cout << array1[x][y] << "      ";
        }
        cout << endl;
    }
    getch();
}
// function to check whether the given matrix is diagonal or not...........
void diagonal(int array1[][5])
{
    int row, col;
    int check = 0;
    cout << "Enter the number of rows of the matrix:";
    cin >> row;
    cout << "Enter the number of columns of the matrix: ";
    cin >> col;
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << "Enter the values of the matrix: ";
            cin >> array1[i][j];
        }
    }
    for (int x = 0; x < row; x++)
    {
        for (int y = 0; y < col; y++)
        {
            if (x != y && array1[x][y] == 0)
            {
                check++;
            }
        }
    }
    if (((row * col) - row) == check)
    {
        cout << "It is a diagonal matrix.........";
    }
    else
    {
        cout << "It is not a diagonal matrix.........";
    }
    getch();
}
// function to check whether the given matrix is symmetric or not........
void symmetric(int array1[][5])
{
    int row, col, count = 0;
    cout << "Enter the number of rows of the matrix:";
    cin >> row;
    cout << "Enter the number of columns of the matrix: ";
    cin >> col;
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << "Enter the values of the matrix: ";
            cin >> array1[i][j];
        }
    }
    for (int y = 0; y < col; y++)
    {
        for (int x = 0; x < row; x++)
        {
            if (array1[x][y] == array1[y][x])
            {
                count++;
            }
        }
    }
    if (count == row * col)
    {
        cout << "It is a symmetric matrix......";
    }
    else
    {
        cout << "It is not a symmetric matrix...........";
    }
    getch();
}

// function for the header..........
void header()
{
    cout << "                               ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
    cout << "                               __________________________________________________________" << endl;
    cout << "                                                  MATRIX CALCULATOR" << endl;
    cout << "                               __________________________________________________________" << endl;
    cout << "                               ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
}