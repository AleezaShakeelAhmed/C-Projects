#include <iostream>
using namespace std;
int x, y, w;
int chocolates_parcel(int x, int y, int w);
main()
{
    cout << "Enter number of small available chocolates: " << endl;
    cin >> x;
    cout << "Enter number of large available chocolates: " << endl;
    cin >> y;
    cout << "Enter desired weight of the final parcel order: " << endl;
    cin >> w;
    int result = chocolates_parcel(x, y, w);
    cout << result;
}
int chocolates_parcel(int x, int y, int w)
{
    int a, b, c, z, s;
    a = x * 2;
    b = y * 5;
    c = a + b;
    if (c == w)
    {
        return x;
    }
    else if (c > w)
    {
        b = c - w;
        
        z = b / 2;
        s = x - z;
        return s;
    }
    else 
    {
        return -1;
    }
    

}
