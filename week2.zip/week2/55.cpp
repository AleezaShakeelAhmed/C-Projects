#include <iostream> 
#include <cmath>
using namespace std;
float secret(int n);
main()
{
    int n;
    cout << "Enter a number: " << endl;
    cin >> n;
    float result = secret(n);
    cout << result << endl;
}
float secret(int n)
{
    float a, b, d, e, f;
    if (n >= 10 && n < 53)
    {
        a = n % 10;
        b = n / 10;
        d = pow(b, a);
        e = a * b;
        f = d - e;
    }
   
    return f;

}