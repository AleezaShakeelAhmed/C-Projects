#include <iostream>
using namespace std;
char x;
int y;
void chessboard(char x, int y);
main()
{
    cout << "Enter the coordinate as a character: " << endl;
    cin >> x;
    cout << "Enter the coordinate as a number: " << endl;
    cin >> y;
    chessboard(x, y);
}
void chessboard(char x, int y)
{
    if (x == 'A')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "white";
        }
        else if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "black";
        }
    }
    else if (x == 'B')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "black";
        }
        if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "white";
        }
    }
    else if (x == 'C')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "white";
        }
        else if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "black";
        }
    }
    else if (x == 'D')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "black";
        }
        if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "white";
        }
    }
    else if (x == 'E')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "white";
        }
        else if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "black";
        }
    }
    else if (x == 'F')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "black";
        }
        if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "white";
        }
    }
    else if (x == 'G')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "white";
        }
        else if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "black";
        }
    }
    else if (x == 'H')
    {
        if (y == 1 || y == 3 || y == 5 || y == 7)
        {
            cout << "black";
        }
        if (y == 2 || y == 4 || y == 6 || y == 8)
        {
            cout << "white";
        }
    }
}
