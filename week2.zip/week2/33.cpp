#include <iostream>
using namespace std;
main()
{
    int a, b, c, d;

    cout << "Enter first number: " << endl;
    cin >> a;
    cout << "Enter second number: " << endl;
    cin >> b;
    cout << "Enter third number: " << endl;
    cin >> c;
    d = a + b - c;
    cout << d;
}
