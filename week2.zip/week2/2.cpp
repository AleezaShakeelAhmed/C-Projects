#include <iostream>
using namespace std;
int calculatebonus(int day);

main()
{
    int day;
    cout << "Enter the day : "<<endl;
                            cin >>
        day;
     int result = calculatebonus(day);
    cout << result;
}
int calculatebonus(int day)
{
    int sum,l;
    if (day <= 32)
    {
        sum=day*0;

    }
    else if (day >= 33 && day <= 40)
    {
        l = day - 32;
        sum = (32 * 0) + (l * 325);

    }
    else if (day >= 41 && day <= 48)
    {
        l = day - 40;
        sum = (32 * 0) + (8 * 325) + (l * 550);
        
    }
    else 
    {
        l = day - 48;
        sum = (0*32)+ (8 * 325) + (8 * 550) + (l * 600);
        
    }
    return sum;
}