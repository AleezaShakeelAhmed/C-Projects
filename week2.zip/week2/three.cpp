#include<iostream>
using namespace std;
int a=1;

void g(){
    a=2;
    cout<<a<<endl;

}
void f(){
    cout<<a<<endl;
    g();

}
void h(){
    a=3;
    cout<<a<<endl;
}
main(){
cout<<a<<endl;
f();
cout<<a<<endl;
h();
cout<<a<<endl;
}