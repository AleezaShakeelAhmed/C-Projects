#include<iostream>
using namespace std;
void calculateyears(int h);
main(){
    int h;
    cout<<"Enter human years: "<<endl;
    cin>>h;
    calculateyears(h);
    

}
void calculateyears(int h){
    int a,c,d;
    if(h==1)
    {
        cout<<"Human years: 1"<<endl;
        cout<<"Cat years: 15"<<endl;
        cout<<"Dog years: 15"<<endl;
    }
    else if(h==2){
        cout<<"Human years: 2"<<endl;
        c=15+9;
        cout<<"Cat years: "<<c<<endl;
        d=15+9;
        cout<<"Dog years: "<<d<<endl;


    }
    else if(h>3){
         cout<<"Human years: "<<h<<endl;
        a=h-2;
        c=24+(4*a);
        cout<<"Cat years: "<<c<<endl;

        d=24+(5*a);
        
        cout<<"Dog years: "<<d<<endl;


    }
}
