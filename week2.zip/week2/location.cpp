#include <iostream>
using namespace std;

string pointlocation(int h, int x, int y);
int main()
{
    int h, x, y;
    cout << "Enter the height: " << endl;
    cin >> h;
    cout << "Enter the x component: " << endl;
    cin >> x;
    cout << "Enter the y component: " << endl;
    cin >> y;
    cout<< pointlocation(h, x, y);
    
}
string pointlocation(int h, int x, int y)
{
    if (x > 0 && x < (3 * h))
    {
        if (y > 0 && y < h)
        {
            return "Inside";
        }
    }
    if (x >= h && x <= (2 * h))
    {
        if (y > h && y < (4 * h))
        {
        return "Inside";
        }
    }
    if ((x >= 0 && x <= (3 * h)) && y == 0)
    {
        return "Border";
    }
    if (x == 0 && y <= h)
    {
        return "Border";
    }
    if (x == (3 * h) && y <= h)
    {
        return "Border";
    }
    if (x == h && (y >= h && y <= (4 * h)))
    {
        return "Border";
    }
    if (x == (2 * h) && (y >= h && y <= (4 * h)))
    {
        return "Border";
    }
    if ((x >= 0 && x <=  h) && y ==  h)
    {
        return "Border";
    }
    // else if ((x >= 0 && x < (2 * h)) && y == h)
    // {
    //     a = "Border";
    // }
    if (x >= (2 * h) && x <= (3 * h) && y == h)
    {
        return "Border";
    }
    
        return "Outside";
    
}
