#include<iostream>
using namespace std;
string item;
float price;
void has_valid_price(string item,float price);
main(){
    cout<<"Enter the item: "<<endl;
    cin>>item;
    cout<<"Enter the price: "<<endl;
    cin>>price;
    has_valid_price(item,price);



}
void has_valid_price(string item,float price){
    if(price>=0){
        cout<<"The price of "<<item<<" is valid";
    }
    else if(price<0){
        cout<<"The price of "<<item<<" is invalid";
    }

}
