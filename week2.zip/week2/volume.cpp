#include <iostream>
#include <cmath>
using namespace std;
float pyramidvolume(float length, float width, float height, string units);
main()
{

    float length, width, height;
    string units;
    cout << "Enter length in meters: " << endl;
    cin >> length;
    cout << "Enter width in meters: " << endl;
    cin >> width;
    cout << "Enter hight in meters: " << endl;
    cin >> height;
    cout << "Enter units in which you want to see the answer: " << endl;
    cin >> units;
    float result = pyramidvolume(length, width, height, units);
    cout << result << " cubic " << units << endl;
}
float pyramidvolume(float length, float width, float height, string units)
{
    float volume, v;

    if (units == "meters")
    {
        volume = (length * width * height)/3.0;
        v=volume;
        
    }
    else if (units == "millimeters")
    { 
        volume = (length * width * height)/3.0;
        v = volume * 1000000000;
    
    }
    else if (units == "centimeters")
    {
        volume = (length * width * height)/3.0;
    

        v = volume * 1000000;
        
    }
    else if (units == "kilometers")
    {
        volume = (length * width * height)/3.0;
        v = volume / (1000000000);
        
    }
    return v;
}
