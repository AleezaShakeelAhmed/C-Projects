#include <iostream>
using namespace std;

bool isleap(int year);
main()
{int year;
    bool result;
    cout << "Enter year: " << endl;
    cin >> year;
    result = isleap(year);
    if (result == 1)
    {
        cout << "true" << endl;
    }
    else if (result == 0)
    {
        cout << "false" << endl;
    }
}
bool isleap(int year)
{
    if (year % 4 == 0 && year % 100 == 0 && year % 400 == 0)
    {
        return true;
    }
    else if (year % 4 == 0 && year % 100 != 0)
    {
        return true;
    }
    else if (year % 4 != 0)
    {
        return false;
    }
    else if (year % 4 == 0 && year % 100 == 0 && year % 400 != 0)
    {
        return false;
    }
}
