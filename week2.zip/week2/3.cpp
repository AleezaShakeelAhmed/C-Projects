#include <iostream>
using namespace std;
bool isprimpythtriple(int x, int y, int z);
int main()
{
    int x, y, z;
    cout << "Enter the first number: " << endl;
    cin >> x;
    cout << "Enter the second number: " << endl;
    cin >> y;
    cout << "Enter the third number: " << endl;
    cin >> z;
    bool result = isprimpythtriple(x, y, z);
    if (result == 1)
    {
        cout << "True";
    }
    else
    {
        cout << "False";
    }
}
bool isprimpythtriple(int x, int y, int z)
{

    int a, b, c;
    a = x * x;
    b = y * y;
    c = z * z;
    if (z > x && z > y)
    {
        if (c == a + b)
        {
            return true;
        }
    }
    else if (y > x && y > z)
    {
        if (b == a + c)
        {
            return true;
        }
    }
    else if (x > y && x > z)
    {
        if (a == b + c)
        {
            return true;
        }
    }
    return false;
}