#include <iostream>
using namespace std;
int countleapyears(int y1, int y2);
bool isleap(int year);
main()
{
    int y1, y2, result;
    cout << "Enter first year: " << endl;
    cin >> y1;
    cout << "Enter second year: " << endl;
    cin >> y2;
    result = countleapyears(y1, y2);
    cout << result<<" Leap Years";
}
bool isleap(int year)
{
    if (year % 4 == 0 && year % 100 == 0 && year % 400 == 0)
    {
        return true;
    }
    else if (year % 4 == 0 && year % 100 != 0)
    {
        return true;
    }
    else if (year % 4 != 0)
    {
        return false;
    }
    else if (year % 4 == 0 && year % 100 == 0 && year % 400 != 0)
    {
        return false;
    }
}
int countleapyears(int y1, int y2)
{

    int a, b, c, d, e, f, g, h, i, j, count=0;
    a=y1;
    b = y1 + 1;
    c = y1 + 2;
    d = y1 + 3;
    e = y1 + 4;
    f = y1 + 5;
    g = y1 + 6;
    h = y1 + 7;
    i = y1 + 8;
    j = y1 + 9;
    

    if (isleap(a) == 1)
    {
        count ++;
    }
    if (isleap(b) == 1)
    {
        count++;
    }
    if (isleap(c) == 1)
    {
        count++;
    }
    if (isleap(d) == 1)
    {
        count++;
    }
    if (isleap(e) == 1)
    {
        count++;
    }
    if (isleap(f) == 1)
    {
        count++;
    }
    if (isleap(g) == 1)
    {
        count++;
    }
    if (isleap(h) == 1)
    {
        count++;
    }
    if (isleap(i) == 1)
    {
        count++;
    }
    if (isleap(j) == 1)
    {
        count++;
    }
    return count;
}
