#include <iostream>
using namespace std;
int n1, n2, n3;

void match(int n1, int n2, int n3);
main()
{
    match(n1, n2, n3);
}
void match(int n1, int n2, int n3)
{
    cout << "Enter first number: " << endl;
    cin >> n1;
    cout << "Enter second number: " << endl;
    cin >> n2;
    cout << "Enter third number: " << endl;
    cin >> n3;
    if (n1 != n2 && n2 != n3 && n1 != n3)
    {
        cout << "0" << endl;
    }
    else if (n1 == n2 && n2 == n3)
    {
        cout << "3" << endl;
    }
    else if (n1 == n2)
    {
        cout << "2" << endl;
    }
    else if (n2 == n3)
    {
        cout << "2" << endl;
    }
    else if (n1 == n3)
    {
        cout << "2" << endl;
    }
}
