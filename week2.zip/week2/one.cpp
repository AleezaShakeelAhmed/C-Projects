#include<iostream>
using namespace std;
int x=6;
void f1();
 
main(){
   f1();
   cout<<x;

}
void f1(){
    int x=4;
}
int f2(int a,int b){
    return a+b+x;
}