#include <iostream>
using namespace std;
void isfactorial(int n);

main()
{
    int num;
    cout << "Enter number: " << endl;
    cin >> num;
    isfactorial(num);
}
void isfactorial(int n)
{
    int z = 0;
    int k;
    for (int i = 1; i <= 10; i++)
    {
        int check = 1;
        for (int j = 1; j <= i; j++)
        {
            check = check * (j);
            k = check;
        }
        if (n == k)
        {
            cout << "true";
            z = 1;
            break;
        }
    }
    if (z == 0)
    {
        cout << "false";
    }
}