#include <iostream>
using namespace std;
int doublepay(int day);
int main()
{
    int day;
    cout << "Enter the number of days: " << endl;
    cin >> day;
    int result = doublepay(day);
    cout << result;
}
int doublepay(int day)
{
    int z=1,sum=0;
    for (int i = 1; i <= day; i++)
    {
        sum=sum+z;
        z=z+z;
    }
    return sum;
}