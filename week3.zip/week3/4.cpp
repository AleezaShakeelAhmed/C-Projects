#include <iostream>
using namespace std;
int mystery_func(int n);
main()
{
    int n;
    cout << "Enter a number: " << endl;
    cin >> n;
    
    cout <<mystery_func(n);
}
int mystery_func(int n)
{ 
    int mul=1;
    for(int i=n;i!=0;i=i/10){
       int mod=i%10;
        mul=mul*mod;
    }
    return mul;
}
