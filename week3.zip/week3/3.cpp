#include <iostream>
using namespace std;
int sumdigits(int n1, int n2);
main()
{
    int n1, n2;
    cout << "Enter the first number: " << endl;
    cin >> n1;
    cout << "Enter the second number: " << endl;
    cin >> n2;

    int result = sumdigits(n1, n2);
    cout << result;
}
int sumdigits(int n1, int n2)
{
    int sum = 0;
    int j;
    for (int i = n1; i <= n2; i++)
    {
        for (j = i; j != 0; j = j / 10)
        {
            int module = j % 10;
            sum = sum + module;
        }
    }
    return sum;
}
