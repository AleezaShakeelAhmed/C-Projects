#include <iostream>
using namespace std;
void combinations(int n1, int n2);
main()
{

    int n1, n2;
    cout << "Enter the first number: " << endl;
    cin >> n1;
    cout << "Enter the second number: " << endl;
    cin >> n2;
    combinations(n1, n2);
}
void combinations(int a, int b)
{
    int z=0;
    for (int i = a; i <= b; i++)
    {
        for (int j = a; j <= b; j++)
        {
            for (int k = a; k <= b; k++)
            {
                for (int l = a; l <= b; l++)
                {
                    if (i < j && j < k && k < l)
                    {
                        z=1;
                        cout << i << " " << j << " " << k << " " << l << endl;
                    }
                }
            }
        }
    }
    if (z==0)
    {
        cout<<"Nope";
    }
    
}