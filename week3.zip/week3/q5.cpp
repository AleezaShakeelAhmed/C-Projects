#include<iostream>
using namespace std;
main(){
    int n,r,c,k,a;
    n=5;
    for(r=1;r<=n;r=r+1){
        for(c=1;c<=n-r;c=c+1){
            cout<<" ";
        }
        for(k=1;k<=(2*r-1);k=k+1){
            if(k<r){
                cout<<k;
            }
            else if(k==r){
                cout<<k;
                a=k;
            }
            else {
                a=a-1;
                cout<<a;
            }
        }
        cout<<endl;
    }
}