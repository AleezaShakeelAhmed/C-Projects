#include <iostream>
#include <ctime>
using namespace std;

string guess();
main()
{
    guess();
}
string guess()
{
    int n, num;
    int i = 1;
    while (i <= 3)
    {
        cout << "Enter an integer greater than or equal to 0 and less than 100: " << endl;
        cin >> n;
        // Code that generates the Random Number
        srand(time(0));
        num = rand() % 100;
        return 0;
        if (n < num)
        {
            cout << "Your guess is lower than the number." << '\n'
                 << "Guess again!" << endl;
        }
        else if (n > num)
        {
            cout << "Your guess is higher than the number." << '\n'
                 << "Guess again!" << endl;
        }
        else if (n == num)
        {
            cout << " You guessed the correct number." << endl;
            break;
        }
    }
    cout << "Sorry u lost";
}
