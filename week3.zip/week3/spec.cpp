#include <iostream>
using namespace std;
void specialnumber(int n);
main()
{
    int n;
    cout << "Enter a number: " << endl;
    cin >> n;
    specialnumber(n);
}
void specialnumber(int n)
{
    int a, b, c, d, e, f, g;
    for (int i = 1111; i <= 9999; i++)
    {
        a = i % 10;
        b = i / 10;
        c = b % 10;
        d = b / 10;
        e = d % 10;
        f = d / 10;
        g = f % 10;
        if (a != 0 && c != 0 && e != 0 && g != 0)
        {
            if (n % a == 0 && n % c == 0 && n % e == 0 && n % g == 0)
            {
                cout << a << c << e << g << " ";
            }
        }
    }
}
