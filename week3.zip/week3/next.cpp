#include <iostream>
using namespace std;
int nextprime(int n);
bool isprime(int n);

main()
{
    int n;
    cout << "Enter a number: " << endl;
    cin >> n;
    cout << nextprime(n);
}
bool isprime(int n)
{
    for (int i = 2; i < n; i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }
    return true;
}

int nextprime(int n)
{
    if (isprime(n) == 1)
    {
        return n;
    }
    else
    {
        for (int i = n; i != 0; i++)
        {
            if (isprime(i) == 1)
            {
                return i;
            }
        }
    }
}
