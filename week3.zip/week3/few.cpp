#include<iostream>
using namespace std;
int collatz(int n);
main(){
    int a,b;
    cout<<"Enter the first integer: "<<endl;
    cin>>a;
    cout<<"Enter the second integer: "<<endl;
    cin>>b;
    int r1=collatz(a);
    int r2=collatz(b);
    if(r1<r2){
        cout<<"a"<<endl;
    }
    else{
         cout<<"b"<<endl;
    }

}
int collatz(int n){
{
    int count = 0;
    while (n != 1)
    {
        if (n % 2 == 0)
        {
            n = n / 2;
            count++;
        }
       else if(n%2!=0)
        {
            n = (n * 3) + 1;
            count++;
        }
    }
    return count;
}
}
