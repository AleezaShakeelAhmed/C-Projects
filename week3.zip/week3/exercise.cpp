#include<iostream>
using namespace std;
void fort(int n);
main(){
    int n;
    cout<<"Enter a number: "<<endl;
    cin>>n;
    fort(n);
}
void fort(int n){
  for(int i=1;i<=n;i++){
      for(int j=1;j<=2*n;j++){
          cout<<
      }
  }
}
