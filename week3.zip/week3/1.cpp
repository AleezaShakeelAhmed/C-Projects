#include <iostream>
#include <conio.h>
using namespace std;
// string truncatable(int n);
string isPrime(int n);
bool rightprime(int num);

main()
{
    int n;
    cout << "Entrer a number: " << endl;
    cin >> n;
    cout << isPrime(n);
}
string isPrime(int n)
{
    string a;
    bool check=true;
    // Corner case
    if (n <= 1)
    {
        a = "none";
    }
    //   check for right prime
    for (int i = n; i >= 0; i=i/10)
    {
       check= rightprime(i);
       if (check == false)
       {
           break;
       }
    }
    if (check == true)
    {
        return "Right Prime";
    }
    
    // check for prime
    check=rightprime(n);
    if (check == true)
    {
        return "Prime";
    }
    

    // Check from 2 to n-1
    for (int i = 2; i < n; i++)
    {
        if (n % i == 0)
        {
            a= "none";
        }
    }
    return a;
}
bool rightprime(int num)
{
    int chk=0;
    for(int i=2; i<num; i++)
    {
        if(num%i==0)
        {
            chk++;
            break;
        }
    }
    if(chk==0)
        return true;
    else
        return false;
}