#include <iostream>
using namespace std;
void character(char c);
main()
{ 
    char c;
    character(c);
}
void character(char c)
{
    while (c != '#')
    {
        cout << "Enter the character: " << endl;
        cin >> c;
        if (c == 'a' || c == 'b' || c == 'c' || c == 'A' || c == 'B' || c == 'C')
        {
            cout << "2"<<endl;
        }
        else if (c == 'd' || c == 'e' || c == 'f' || c == 'D' || c == 'E' || c == 'F')
        {
            cout << "3"<<endl;
        }
        else if (c == 'g' || c == 'h' || c == 'i' || c == 'G' || c == 'H' || c == 'I')
        {
            cout << "4"<<endl;
        }
        else if (c == 'J' || c == 'K' || c == 'L' || c == 'j' || c == 'k' || c == 'l')
        {
            cout << "5"<<endl;
        }
        else if (c == 'm' || c == 'n' || c == 'o' || c == 'M' || c == 'N' || c == 'O')
        {
            cout << "6"<<endl;
        }
        else if (c == 'P' || c == 'Q' || c == 'R' || c == 'S' || c == 'p' || c == 'q' || c == 'r' || c == 's')
        {
            cout << "7"<<endl;
        }
        else if (c == 't' || c == 'u' || c == 'v' || c == 'T' || c == 'U' || c == 'V')
        {
            cout << "8"<<endl;
        }
        else if (c == 'W' || c == 'X' || c == 'Y' || c == 'Z' || c == 'w' || c == 'x' || c == 'y' || c == 'z')
        {
            cout << "9"<<endl;
        }
    }
}
