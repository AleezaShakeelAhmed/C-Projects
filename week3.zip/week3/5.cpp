#include <iostream>
#include <time.h>
using namespace std;
int randomnumber();
main()
{
    randomnumber();
}
int randomnumber()
{
    int a=0,b;
    for (int i = 0; i < 5; i++)
    {
        srand(time(0));
        b= (rand() % 6);
        if (b!=a)
        {
            cout<<b;
            a=b;
        }
        
        
    }
}
