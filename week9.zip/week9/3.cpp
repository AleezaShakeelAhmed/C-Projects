#include <iostream>
#include <conio.h>
using namespace std;
void largestcolumnfirst(int array[][5], int rowsize, int colsize);
int main()
{
    int array[3][5];
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cout << "Enter numbers: ";
            cin >> array[i][j];
        }
    }
    int rowsize = sizeof(array) / sizeof(array[0]);
    int colsize = sizeof(array[0]) / sizeof(array);
    largestcolumnfirst(array, rowsize, colsize);
}
void largestcolumnfirst(int array[][5], int rowsize, int colsize)
{
    int a;
    int sum[5];
    for (int row = 0; row < 3; row++)
    {
        for (int col = 0; col < 5; col++)
        {
            sum[row] = sum[row] + array[col][row];
        }
    }
    for (int i = 0; i < 5; i++)
    {
        if (sum[i] < sum[i + 1])
        {
            int temp = sum[i];
            sum[i] = sum[i + 1];
            sum[i + 1] = temp;
            a = i;
        }
    }
    int temp1 = array[0][0];
    int temp2 = array[1][0];
    int temp3 = array[2][0];
    array[0][0] = array[0][a];
    array[1][0] = array[1][a];
    array[2][0] = array[2][a];
    array[0][a] = temp1;
    array[1][a] = temp2;
    array[2][a] = temp3;

    for (int x = 0; x < 3; x++)
    {
        for (int y = 0; y < 5; y++)
        {
            cout << array[x][y];
        }
        cout << endl;
    }
}
