#include <iostream>
#include <conio.h>
using namespace std;
void ziplt(string array1[], int s1, string array2[], int s2);
int main()
{
    string array1[5];
    string array2[5];
    int s1, s2;
    cout << "Enter the size of first array:";
    cin >> s1;
    cout << "Enter the size of second array:";
    cin >> s2;
    for (int i = 0; i < s1; i++)
    {
        cout << "Enter women name: ";
        cin >> array1[i];
    }
    for (int j = 0; j < s2; j++)
    {
        cout << "Enter man name: ";
        cin >> array2[j];
    }
    ziplt(array1, s1, array2, s2);
}
void ziplt(string array1[], int s1, string array2[], int s2)
{
    string newarray[3];
    if (s1 != s2)
    {
        cout << "size don't match" << endl;
    }
    else if (s1 == s2)
    {
        for (int x = 0; x < s1; x++)
        {
            newarray[0] = array1[x];
            newarray[1] = ",";
            newarray[2] = array2[x];
             cout<<"             "<<endl;
            for (int z = 0; z < 3; z++)
            {
                cout << newarray[z];
            }
            cout<<endl;
        }
        
    }
}
