#include <iostream>
#include <conio.h>
using namespace std;
bool isminisokudo(int array[][3], int rowsize, int colsize);
int main()
{
    bool result;
    int array[3][3];
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cout << "Enter numbers: ";
            cin >> array[i][j];
        }
    }
    int rowsize = sizeof(array) / sizeof(array[0]);
    int colsize = sizeof(array[0]) / sizeof(array);
    result = isminisokudo(array, rowsize, colsize);
    if (result == 1)
    {
        cout << "true";
    }
    if (result == 0)
    {
        cout << "false";
    }
}
bool isminisokudo(int array[][3], int rowsize, int colsize)
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (array[i][j] > 9 || array[i][j] <= 0)
            {
                return false;
            }
            else
            {
                for (int x = i; x < 3; x++)
                {
                    for (int y = j + 1; y < 3; y++)
                    {
                        if (array[i][j] == array[x][y])
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
            }
        }
    }
}