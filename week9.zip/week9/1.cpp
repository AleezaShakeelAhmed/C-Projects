#include <iostream>
#include <conio.h>
using namespace std;
void flatten(int array2[][2], int rowsize, int colsize);
int main()
{

    int array2[2][2];
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            cout << "Enter numbers:";
            cin >> array2[i][j];
        }
    }
    int rowsize = sizeof(array2) / sizeof(array2[0]);
    int colsize = sizeof(array2[0]) / sizeof(array2);
    flatten(array2, rowsize, colsize);
}
void flatten(int array2[][2], int rowsize, int colsize)
{
    int array1[4];
    int a=0;
    for (int x = 0; x < 2; x++)
    {
        for (int y = 0; y < 2; y++)
        {
            array1[a] = array2[x][y];
            a++;
        }
    }
    for (int z = 0; z < 4; z++)
    {
        cout << array1[z];
    }
}
